-- Copyright (C) 1991-2011 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 32-bit"
-- VERSION "Version 11.1 Build 173 11/01/2011 SJ Web Edition"

-- DATE "07/13/2020 14:35:35"

-- 
-- Device: Altera EP4CE30F23C8 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	adc_dac_interface IS
    PORT (
	AD_CONVST : OUT std_logic;
	AD_SCLK : OUT std_logic;
	AD_CS : OUT std_logic;
	AD_SDI : OUT std_logic;
	DA_CLK : OUT std_logic;
	DA1_LD : OUT std_logic;
	DA1_SRI : OUT std_logic;
	DA2_LD : OUT std_logic;
	DA2_SRI : OUT std_logic;
	DA3_LD : OUT std_logic;
	DA3_SRI : OUT std_logic;
	DA4_LD : OUT std_logic;
	DA4_SRI : OUT std_logic;
	DA5_LD : OUT std_logic;
	DA5_SRI : OUT std_logic;
	DA6_LD : OUT std_logic;
	DA6_SRI : OUT std_logic;
	LED : OUT std_logic_vector(3 DOWNTO 0);
	CLKY2 : IN std_logic;
	SYS_RESET : IN std_logic;
	AD_SDO : IN std_logic
	);
END adc_dac_interface;

-- Design Ports Information
-- AD_CONVST	=>  Location: PIN_E1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- AD_SCLK	=>  Location: PIN_E3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- AD_CS	=>  Location: PIN_C1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- AD_SDI	=>  Location: PIN_B2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA_CLK	=>  Location: PIN_Y17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA1_LD	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA1_SRI	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA2_LD	=>  Location: PIN_AA16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA2_SRI	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA3_LD	=>  Location: PIN_W13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA3_SRI	=>  Location: PIN_W14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA4_LD	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA4_SRI	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA5_LD	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA5_SRI	=>  Location: PIN_AB14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA6_LD	=>  Location: PIN_AA13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- DA6_SRI	=>  Location: PIN_AB13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LED[0]	=>  Location: PIN_AB18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LED[1]	=>  Location: PIN_AA19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LED[2]	=>  Location: PIN_AB19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- LED[3]	=>  Location: PIN_AA18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SYS_RESET	=>  Location: PIN_E4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLKY2	=>  Location: PIN_G1,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- AD_SDO	=>  Location: PIN_B1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF adc_dac_interface IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_AD_CONVST : std_logic;
SIGNAL ww_AD_SCLK : std_logic;
SIGNAL ww_AD_CS : std_logic;
SIGNAL ww_AD_SDI : std_logic;
SIGNAL ww_DA_CLK : std_logic;
SIGNAL ww_DA1_LD : std_logic;
SIGNAL ww_DA1_SRI : std_logic;
SIGNAL ww_DA2_LD : std_logic;
SIGNAL ww_DA2_SRI : std_logic;
SIGNAL ww_DA3_LD : std_logic;
SIGNAL ww_DA3_SRI : std_logic;
SIGNAL ww_DA4_LD : std_logic;
SIGNAL ww_DA4_SRI : std_logic;
SIGNAL ww_DA5_LD : std_logic;
SIGNAL ww_DA5_SRI : std_logic;
SIGNAL ww_DA6_LD : std_logic;
SIGNAL ww_DA6_SRI : std_logic;
SIGNAL ww_LED : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_CLKY2 : std_logic;
SIGNAL ww_SYS_RESET : std_logic;
SIGNAL ww_AD_SDO : std_logic;
SIGNAL \CLKY2~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \I_ad5441_interface_1|dac_clk_t~q\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[3]~11_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[3]~19_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[11]~35_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[13]~39_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[0]~7_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[3]~11_combout\ : std_logic;
SIGNAL \I_ads8330_interface|sdi_t~0_combout\ : std_logic;
SIGNAL \I_power_on_reset|LessThan0~2_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector3~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector1~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Add0~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector7~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector9~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector10~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_clk_t~1_combout\ : std_logic;
SIGNAL \dac_data~2_combout\ : std_logic;
SIGNAL \dac_data~4_combout\ : std_logic;
SIGNAL \dac_data~6_combout\ : std_logic;
SIGNAL \dac_data~7_combout\ : std_logic;
SIGNAL \dac_data~8_combout\ : std_logic;
SIGNAL \dac_data~9_combout\ : std_logic;
SIGNAL \dac_data~11_combout\ : std_logic;
SIGNAL \dac_data~12_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[0]~45_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector26~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector24~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector30~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector31~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector28~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector32~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector33~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector23~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector7~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector15~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector16~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector6~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector18~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector19~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector20~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector21~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_2~7_combout\ : std_logic;
SIGNAL \AD_SDO~input_o\ : std_logic;
SIGNAL \AD_CONVST~output_o\ : std_logic;
SIGNAL \AD_SCLK~output_o\ : std_logic;
SIGNAL \AD_CS~output_o\ : std_logic;
SIGNAL \AD_SDI~output_o\ : std_logic;
SIGNAL \DA_CLK~output_o\ : std_logic;
SIGNAL \DA1_LD~output_o\ : std_logic;
SIGNAL \DA1_SRI~output_o\ : std_logic;
SIGNAL \DA2_LD~output_o\ : std_logic;
SIGNAL \DA2_SRI~output_o\ : std_logic;
SIGNAL \DA3_LD~output_o\ : std_logic;
SIGNAL \DA3_SRI~output_o\ : std_logic;
SIGNAL \DA4_LD~output_o\ : std_logic;
SIGNAL \DA4_SRI~output_o\ : std_logic;
SIGNAL \DA5_LD~output_o\ : std_logic;
SIGNAL \DA5_SRI~output_o\ : std_logic;
SIGNAL \DA6_LD~output_o\ : std_logic;
SIGNAL \DA6_SRI~output_o\ : std_logic;
SIGNAL \LED[0]~output_o\ : std_logic;
SIGNAL \LED[1]~output_o\ : std_logic;
SIGNAL \LED[2]~output_o\ : std_logic;
SIGNAL \LED[3]~output_o\ : std_logic;
SIGNAL \CLKY2~input_o\ : std_logic;
SIGNAL \CLKY2~inputclkctrl_outclk\ : std_logic;
SIGNAL \SYS_RESET~input_o\ : std_logic;
SIGNAL \I_power_on_reset|count[1]~15_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[1]~16\ : std_logic;
SIGNAL \I_power_on_reset|count[2]~17_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[2]~18\ : std_logic;
SIGNAL \I_power_on_reset|count[3]~20\ : std_logic;
SIGNAL \I_power_on_reset|count[4]~21_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[4]~22\ : std_logic;
SIGNAL \I_power_on_reset|count[5]~24\ : std_logic;
SIGNAL \I_power_on_reset|count[6]~26\ : std_logic;
SIGNAL \I_power_on_reset|count[7]~27_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[7]~28\ : std_logic;
SIGNAL \I_power_on_reset|count[8]~29_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[8]~30\ : std_logic;
SIGNAL \I_power_on_reset|count[9]~31_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[9]~32\ : std_logic;
SIGNAL \I_power_on_reset|count[10]~33_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[10]~34\ : std_logic;
SIGNAL \I_power_on_reset|count[11]~36\ : std_logic;
SIGNAL \I_power_on_reset|count[12]~37_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[12]~38\ : std_logic;
SIGNAL \I_power_on_reset|count[13]~40\ : std_logic;
SIGNAL \I_power_on_reset|count[14]~41_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[6]~25_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[5]~23_combout\ : std_logic;
SIGNAL \I_power_on_reset|LessThan0~0_combout\ : std_logic;
SIGNAL \I_power_on_reset|LessThan0~1_combout\ : std_logic;
SIGNAL \I_power_on_reset|count[14]~42\ : std_logic;
SIGNAL \I_power_on_reset|count[15]~43_combout\ : std_logic;
SIGNAL \I_power_on_reset|LessThan0~3_combout\ : std_logic;
SIGNAL \I_power_on_reset|reset_t~0_combout\ : std_logic;
SIGNAL \I_power_on_reset|reset_t~q\ : std_logic;
SIGNAL \reset~combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[0]~8\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[1]~9_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.idle~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.idle~q\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[3]~18\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[4]~19_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[4]~20\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[5]~21_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~11_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.issue_cs~q\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[5]~13_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Equal0~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Equal1~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[5]~11_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[5]~12_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[5]~14_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[1]~10\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[2]~15_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[2]~16\ : std_logic;
SIGNAL \I_ads8330_interface|count_1[3]~17_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Equal2~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector25~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~8_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~9_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.issue_convst~q\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~7_combout\ : std_logic;
SIGNAL \I_ads8330_interface|convst_n_t~q\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~10_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.data_transfer~q\ : std_logic;
SIGNAL \I_ads8330_interface|sclk_t~1_combout\ : std_logic;
SIGNAL \I_ads8330_interface|sclk_t~q\ : std_logic;
SIGNAL \I_ads8330_interface|cs_n_t~1_combout\ : std_logic;
SIGNAL \I_ads8330_interface|cs_n_t~q\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[0]~5_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[1]~15_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[1]~16_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[0]~6\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[1]~7_combout\ : std_logic;
SIGNAL \~GND~combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[1]~8\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[2]~9_combout\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[2]~10\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[3]~12\ : std_logic;
SIGNAL \I_ads8330_interface|count_2[4]~13_combout\ : std_logic;
SIGNAL \I_ads8330_interface|sdi_t~1_combout\ : std_logic;
SIGNAL \I_ads8330_interface|sdi_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state~8_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state.idle~q\ : std_logic;
SIGNAL \I_ads8330_interface|data_val~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~12_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state~13_combout\ : std_logic;
SIGNAL \I_ads8330_interface|next_state.wait_state~q\ : std_logic;
SIGNAL \I_ads8330_interface|data_val~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[0]~5_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[1]~8\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[2]~9_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[2]~10\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[3]~12\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[4]~14_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[2]~13_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[0]~6\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1[1]~7_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Equal0~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state~6_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state~7_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state.data_transfer~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state~5_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|next_state.issue_ld~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_ld_n_t~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_ld_n_t~feeder_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_2~6_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_2[1]~5_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector8~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector8~1_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector14~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector13~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector12~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector11~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector10~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector39~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector27~0_combout\ : std_logic;
SIGNAL \dac_data~3_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector22~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector39~1_combout\ : std_logic;
SIGNAL \dac_data[10]~1_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector4~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_2~4_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector9~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector8~2_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector25~1_combout\ : std_logic;
SIGNAL \dac_data~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector2~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~1_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Add0~1_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_2~8_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector5~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector29~0_combout\ : std_logic;
SIGNAL \dac_data~5_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector6~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector8~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~2_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~3_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector17~0_combout\ : std_logic;
SIGNAL \I_ads8330_interface|Selector34~0_combout\ : std_logic;
SIGNAL \dac_data~10_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector11~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~4_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~5_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~6_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Selector0~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~7_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|Mux0~8_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_sri_t~0_combout\ : std_logic;
SIGNAL \I_ad5441_interface_1|dac_sri_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_2|dac_ld_n_t~feeder_combout\ : std_logic;
SIGNAL \I_ad5441_interface_2|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_3|dac_ld_n_t~feeder_combout\ : std_logic;
SIGNAL \I_ad5441_interface_3|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_4|dac_ld_n_t~feeder_combout\ : std_logic;
SIGNAL \I_ad5441_interface_4|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_5|dac_ld_n_t~feeder_combout\ : std_logic;
SIGNAL \I_ad5441_interface_5|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_6|dac_ld_n_t~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|count_1\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \I_ad5441_interface_1|count_2\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \I_ad5441_interface_1|dac_data_t\ : std_logic_vector(12 DOWNTO 1);
SIGNAL \I_ads8330_interface|adc_data\ : std_logic_vector(16 DOWNTO 0);
SIGNAL \I_ads8330_interface|adc_data_t\ : std_logic_vector(16 DOWNTO 0);
SIGNAL \I_ads8330_interface|count_1\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \I_ads8330_interface|count_2\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \I_power_on_reset|count\ : std_logic_vector(15 DOWNTO 0);
SIGNAL dac_data : std_logic_vector(11 DOWNTO 0);
SIGNAL \I_ads8330_interface|ALT_INV_next_state.data_transfer~q\ : std_logic;
SIGNAL \I_ad5441_interface_1|ALT_INV_next_state.data_transfer~q\ : std_logic;
SIGNAL \I_ads8330_interface|ALT_INV_next_state.wait_state~q\ : std_logic;

BEGIN

AD_CONVST <= ww_AD_CONVST;
AD_SCLK <= ww_AD_SCLK;
AD_CS <= ww_AD_CS;
AD_SDI <= ww_AD_SDI;
DA_CLK <= ww_DA_CLK;
DA1_LD <= ww_DA1_LD;
DA1_SRI <= ww_DA1_SRI;
DA2_LD <= ww_DA2_LD;
DA2_SRI <= ww_DA2_SRI;
DA3_LD <= ww_DA3_LD;
DA3_SRI <= ww_DA3_SRI;
DA4_LD <= ww_DA4_LD;
DA4_SRI <= ww_DA4_SRI;
DA5_LD <= ww_DA5_LD;
DA5_SRI <= ww_DA5_SRI;
DA6_LD <= ww_DA6_LD;
DA6_SRI <= ww_DA6_SRI;
LED <= ww_LED;
ww_CLKY2 <= CLKY2;
ww_SYS_RESET <= SYS_RESET;
ww_AD_SDO <= AD_SDO;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLKY2~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLKY2~input_o\);
\I_ads8330_interface|ALT_INV_next_state.data_transfer~q\ <= NOT \I_ads8330_interface|next_state.data_transfer~q\;
\I_ad5441_interface_1|ALT_INV_next_state.data_transfer~q\ <= NOT \I_ad5441_interface_1|next_state.data_transfer~q\;
\I_ads8330_interface|ALT_INV_next_state.wait_state~q\ <= NOT \I_ads8330_interface|next_state.wait_state~q\;

-- Location: FF_X11_Y36_N23
\I_ads8330_interface|count_2[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_2[3]~11_combout\,
	asdata => \~GND~combout\,
	sload => \I_ads8330_interface|count_2[1]~15_combout\,
	ena => \I_ads8330_interface|count_2[1]~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_2\(3));

-- Location: FF_X16_Y37_N3
\I_ad5441_interface_1|dac_data_t[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector3~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(9));

-- Location: FF_X16_Y37_N15
\I_ad5441_interface_1|dac_data_t[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector1~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(11));

-- Location: FF_X16_Y37_N27
\I_ad5441_interface_1|dac_data_t[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector7~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(5));

-- Location: FF_X18_Y37_N3
\I_ad5441_interface_1|dac_data_t[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector9~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(3));

-- Location: FF_X18_Y37_N7
\I_ad5441_interface_1|dac_data_t[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector10~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(2));

-- Location: FF_X14_Y37_N9
\I_ad5441_interface_1|dac_clk_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|dac_clk_t~1_combout\,
	asdata => VCC,
	sload => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_clk_t~q\);

-- Location: FF_X14_Y36_N23
\I_power_on_reset|count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[11]~35_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(11));

-- Location: FF_X14_Y36_N27
\I_power_on_reset|count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[13]~39_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(13));

-- Location: FF_X17_Y36_N13
\I_ads8330_interface|count_1[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[0]~7_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(0));

-- Location: LCCOMB_X11_Y36_N22
\I_ads8330_interface|count_2[3]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[3]~11_combout\ = (\I_ads8330_interface|count_2\(3) & (\I_ads8330_interface|count_2[2]~10\ & VCC)) # (!\I_ads8330_interface|count_2\(3) & (!\I_ads8330_interface|count_2[2]~10\))
-- \I_ads8330_interface|count_2[3]~12\ = CARRY((!\I_ads8330_interface|count_2\(3) & !\I_ads8330_interface|count_2[2]~10\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_2\(3),
	datad => VCC,
	cin => \I_ads8330_interface|count_2[2]~10\,
	combout => \I_ads8330_interface|count_2[3]~11_combout\,
	cout => \I_ads8330_interface|count_2[3]~12\);

-- Location: FF_X15_Y37_N7
\I_ad5441_interface_1|count_1[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_1[3]~11_combout\,
	sclr => \I_ad5441_interface_1|count_1[2]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_1\(3));

-- Location: FF_X14_Y36_N7
\I_power_on_reset|count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[3]~19_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(3));

-- Location: LCCOMB_X14_Y36_N6
\I_power_on_reset|count[3]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[3]~19_combout\ = (\I_power_on_reset|count\(3) & (\I_power_on_reset|count[2]~18\ $ (GND))) # (!\I_power_on_reset|count\(3) & (!\I_power_on_reset|count[2]~18\ & VCC))
-- \I_power_on_reset|count[3]~20\ = CARRY((\I_power_on_reset|count\(3) & !\I_power_on_reset|count[2]~18\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(3),
	datad => VCC,
	cin => \I_power_on_reset|count[2]~18\,
	combout => \I_power_on_reset|count[3]~19_combout\,
	cout => \I_power_on_reset|count[3]~20\);

-- Location: LCCOMB_X14_Y36_N22
\I_power_on_reset|count[11]~35\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[11]~35_combout\ = (\I_power_on_reset|count\(11) & (\I_power_on_reset|count[10]~34\ $ (GND))) # (!\I_power_on_reset|count\(11) & (!\I_power_on_reset|count[10]~34\ & VCC))
-- \I_power_on_reset|count[11]~36\ = CARRY((\I_power_on_reset|count\(11) & !\I_power_on_reset|count[10]~34\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(11),
	datad => VCC,
	cin => \I_power_on_reset|count[10]~34\,
	combout => \I_power_on_reset|count[11]~35_combout\,
	cout => \I_power_on_reset|count[11]~36\);

-- Location: LCCOMB_X14_Y36_N26
\I_power_on_reset|count[13]~39\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[13]~39_combout\ = (\I_power_on_reset|count\(13) & (\I_power_on_reset|count[12]~38\ $ (GND))) # (!\I_power_on_reset|count\(13) & (!\I_power_on_reset|count[12]~38\ & VCC))
-- \I_power_on_reset|count[13]~40\ = CARRY((\I_power_on_reset|count\(13) & !\I_power_on_reset|count[12]~38\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(13),
	datad => VCC,
	cin => \I_power_on_reset|count[12]~38\,
	combout => \I_power_on_reset|count[13]~39_combout\,
	cout => \I_power_on_reset|count[13]~40\);

-- Location: LCCOMB_X17_Y36_N12
\I_ads8330_interface|count_1[0]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[0]~7_combout\ = \I_ads8330_interface|count_1\(0) $ (VCC)
-- \I_ads8330_interface|count_1[0]~8\ = CARRY(\I_ads8330_interface|count_1\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_1\(0),
	datad => VCC,
	combout => \I_ads8330_interface|count_1[0]~7_combout\,
	cout => \I_ads8330_interface|count_1[0]~8\);

-- Location: LCCOMB_X15_Y37_N6
\I_ad5441_interface_1|count_1[3]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[3]~11_combout\ = (\I_ad5441_interface_1|count_1\(3) & (!\I_ad5441_interface_1|count_1[2]~10\)) # (!\I_ad5441_interface_1|count_1\(3) & ((\I_ad5441_interface_1|count_1[2]~10\) # (GND)))
-- \I_ad5441_interface_1|count_1[3]~12\ = CARRY((!\I_ad5441_interface_1|count_1[2]~10\) # (!\I_ad5441_interface_1|count_1\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_1\(3),
	datad => VCC,
	cin => \I_ad5441_interface_1|count_1[2]~10\,
	combout => \I_ad5441_interface_1|count_1[3]~11_combout\,
	cout => \I_ad5441_interface_1|count_1[3]~12\);

-- Location: FF_X16_Y35_N3
\I_ads8330_interface|adc_data[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector26~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(13));

-- Location: FF_X16_Y35_N7
\I_ads8330_interface|adc_data[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector24~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(15));

-- Location: FF_X16_Y35_N27
\I_ads8330_interface|adc_data[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector30~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(9));

-- Location: FF_X17_Y35_N11
\I_ads8330_interface|adc_data[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector31~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(8));

-- Location: FF_X16_Y35_N5
\I_ads8330_interface|adc_data[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector28~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(11));

-- Location: FF_X17_Y35_N21
\I_ads8330_interface|adc_data[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector32~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(7));

-- Location: FF_X17_Y35_N25
\I_ads8330_interface|adc_data[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector33~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(6));

-- Location: FF_X16_Y35_N31
\I_ads8330_interface|adc_data[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector23~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(16));

-- Location: FF_X16_Y35_N15
\I_ads8330_interface|adc_data_t[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector7~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(15));

-- Location: FF_X17_Y35_N15
\I_ads8330_interface|adc_data_t[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector15~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(7));

-- Location: FF_X17_Y35_N19
\I_ads8330_interface|adc_data_t[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector16~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(6));

-- Location: FF_X16_Y35_N23
\I_ads8330_interface|adc_data_t[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector6~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(16));

-- Location: FF_X17_Y35_N13
\I_ads8330_interface|adc_data_t[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector18~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(4));

-- Location: FF_X17_Y35_N23
\I_ads8330_interface|adc_data_t[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector19~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(3));

-- Location: FF_X17_Y35_N17
\I_ads8330_interface|adc_data_t[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector20~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(2));

-- Location: FF_X17_Y35_N27
\I_ads8330_interface|adc_data_t[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector21~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(1));

-- Location: LCCOMB_X11_Y36_N8
\I_ads8330_interface|sdi_t~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|sdi_t~0_combout\ = (!\I_ads8330_interface|count_2\(0) & (\I_ads8330_interface|count_2\(2) & (\I_ads8330_interface|count_2\(3) & \I_ads8330_interface|count_2\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_2\(0),
	datab => \I_ads8330_interface|count_2\(2),
	datac => \I_ads8330_interface|count_2\(3),
	datad => \I_ads8330_interface|count_2\(1),
	combout => \I_ads8330_interface|sdi_t~0_combout\);

-- Location: FF_X17_Y37_N11
\I_ad5441_interface_1|count_2[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_2~7_combout\,
	ena => \I_ad5441_interface_1|count_2[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_2\(3));

-- Location: LCCOMB_X15_Y36_N6
\I_power_on_reset|LessThan0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|LessThan0~2_combout\ = (!\I_power_on_reset|count\(13) & (!\I_power_on_reset|count\(11) & (!\I_power_on_reset|count\(10) & !\I_power_on_reset|count\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(13),
	datab => \I_power_on_reset|count\(11),
	datac => \I_power_on_reset|count\(10),
	datad => \I_power_on_reset|count\(12),
	combout => \I_power_on_reset|LessThan0~2_combout\);

-- Location: FF_X16_Y37_N19
\dac_data[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~2_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(8));

-- Location: LCCOMB_X16_Y37_N2
\I_ad5441_interface_1|Selector3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector3~0_combout\ = (dac_data(8) & (((\I_ad5441_interface_1|dac_data_t\(9) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(8) & 
-- (((\I_ad5441_interface_1|dac_data_t\(9) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(8),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(9),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector3~0_combout\);

-- Location: FF_X16_Y37_N31
\dac_data[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~4_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(10));

-- Location: LCCOMB_X16_Y37_N14
\I_ad5441_interface_1|Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector1~0_combout\ = (dac_data(10) & (((\I_ad5441_interface_1|dac_data_t\(11) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(10) & 
-- (((\I_ad5441_interface_1|dac_data_t\(11) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(10),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(11),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector1~0_combout\);

-- Location: LCCOMB_X17_Y37_N4
\I_ad5441_interface_1|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Add0~0_combout\ = \I_ad5441_interface_1|count_2\(3) $ (((\I_ad5441_interface_1|count_2\(0)) # ((\I_ad5441_interface_1|count_2\(2)) # (\I_ad5441_interface_1|count_2\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_2\(3),
	datab => \I_ad5441_interface_1|count_2\(0),
	datac => \I_ad5441_interface_1|count_2\(2),
	datad => \I_ad5441_interface_1|count_2\(1),
	combout => \I_ad5441_interface_1|Add0~0_combout\);

-- Location: FF_X16_Y37_N11
\dac_data[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~6_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(4));

-- Location: LCCOMB_X16_Y37_N26
\I_ad5441_interface_1|Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector7~0_combout\ = (dac_data(4) & (((\I_ad5441_interface_1|dac_data_t\(5) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(4) & 
-- (((\I_ad5441_interface_1|dac_data_t\(5) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(4),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(5),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector7~0_combout\);

-- Location: FF_X16_Y37_N13
\dac_data[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~7_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(3));

-- Location: FF_X15_Y37_N23
\dac_data[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~8_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(6));

-- Location: FF_X15_Y37_N17
\dac_data[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~9_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(2));

-- Location: LCCOMB_X18_Y37_N2
\I_ad5441_interface_1|Selector9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector9~0_combout\ = (dac_data(2) & (((\I_ad5441_interface_1|dac_data_t\(3) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(2) & 
-- (((\I_ad5441_interface_1|dac_data_t\(3) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(2),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(3),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector9~0_combout\);

-- Location: FF_X15_Y37_N13
\dac_data[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~11_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(1));

-- Location: LCCOMB_X18_Y37_N6
\I_ad5441_interface_1|Selector10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector10~0_combout\ = (dac_data(1) & (((\I_ad5441_interface_1|dac_data_t\(2) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(1) & 
-- (((\I_ad5441_interface_1|dac_data_t\(2) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(1),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(2),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector10~0_combout\);

-- Location: FF_X15_Y37_N31
\dac_data[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~12_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(11));

-- Location: LCCOMB_X14_Y37_N8
\I_ad5441_interface_1|dac_clk_t~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|dac_clk_t~1_combout\ = (!\I_ad5441_interface_1|next_state.data_transfer~q\) # (!\I_ad5441_interface_1|dac_clk_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_clk_t~q\,
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|dac_clk_t~1_combout\);

-- Location: FF_X15_Y36_N3
\I_power_on_reset|count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[0]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(0));

-- Location: LCCOMB_X16_Y37_N18
\dac_data~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~2_combout\ = (\I_ads8330_interface|adc_data\(13) & (\SYS_RESET~input_o\ & \I_power_on_reset|reset_t~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|adc_data\(13),
	datac => \SYS_RESET~input_o\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \dac_data~2_combout\);

-- Location: LCCOMB_X16_Y37_N30
\dac_data~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~4_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & \I_ads8330_interface|adc_data\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(15),
	combout => \dac_data~4_combout\);

-- Location: LCCOMB_X16_Y37_N10
\dac_data~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~6_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & \I_ads8330_interface|adc_data\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(9),
	combout => \dac_data~6_combout\);

-- Location: LCCOMB_X16_Y37_N12
\dac_data~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~7_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & \I_ads8330_interface|adc_data\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(8),
	combout => \dac_data~7_combout\);

-- Location: LCCOMB_X15_Y37_N22
\dac_data~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~8_combout\ = (\SYS_RESET~input_o\ & (\I_power_on_reset|reset_t~q\ & \I_ads8330_interface|adc_data\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SYS_RESET~input_o\,
	datac => \I_power_on_reset|reset_t~q\,
	datad => \I_ads8330_interface|adc_data\(11),
	combout => \dac_data~8_combout\);

-- Location: LCCOMB_X15_Y37_N16
\dac_data~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~9_combout\ = (\I_power_on_reset|reset_t~q\ & (\I_ads8330_interface|adc_data\(7) & \SYS_RESET~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|reset_t~q\,
	datac => \I_ads8330_interface|adc_data\(7),
	datad => \SYS_RESET~input_o\,
	combout => \dac_data~9_combout\);

-- Location: LCCOMB_X15_Y37_N12
\dac_data~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~11_combout\ = (\SYS_RESET~input_o\ & (\I_power_on_reset|reset_t~q\ & \I_ads8330_interface|adc_data\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SYS_RESET~input_o\,
	datac => \I_power_on_reset|reset_t~q\,
	datad => \I_ads8330_interface|adc_data\(6),
	combout => \dac_data~11_combout\);

-- Location: LCCOMB_X15_Y37_N30
\dac_data~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~12_combout\ = (\SYS_RESET~input_o\ & (\I_power_on_reset|reset_t~q\ & \I_ads8330_interface|adc_data\(16)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SYS_RESET~input_o\,
	datac => \I_power_on_reset|reset_t~q\,
	datad => \I_ads8330_interface|adc_data\(16),
	combout => \dac_data~12_combout\);

-- Location: LCCOMB_X15_Y36_N2
\I_power_on_reset|count[0]~45\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[0]~45_combout\ = \I_power_on_reset|count\(0) $ (\I_power_on_reset|LessThan0~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_power_on_reset|count\(0),
	datad => \I_power_on_reset|LessThan0~3_combout\,
	combout => \I_power_on_reset|count[0]~45_combout\);

-- Location: LCCOMB_X16_Y35_N2
\I_ads8330_interface|Selector26~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector26~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(13)) # ((\I_ads8330_interface|adc_data\(13) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(13) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(13),
	datac => \I_ads8330_interface|adc_data\(13),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector26~0_combout\);

-- Location: LCCOMB_X16_Y35_N6
\I_ads8330_interface|Selector24~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector24~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(15)) # ((\I_ads8330_interface|adc_data\(15) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(15) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(15),
	datac => \I_ads8330_interface|adc_data\(15),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector24~0_combout\);

-- Location: LCCOMB_X16_Y35_N26
\I_ads8330_interface|Selector30~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector30~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(9)) # ((\I_ads8330_interface|adc_data\(9) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(9) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(9),
	datac => \I_ads8330_interface|adc_data\(9),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector30~0_combout\);

-- Location: LCCOMB_X17_Y35_N10
\I_ads8330_interface|Selector31~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector31~0_combout\ = (\I_ads8330_interface|Selector39~0_combout\ & ((\I_ads8330_interface|adc_data\(8)) # ((\I_ads8330_interface|adc_data_t\(8) & \I_ads8330_interface|Selector25~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector39~0_combout\ & (\I_ads8330_interface|adc_data_t\(8) & ((\I_ads8330_interface|Selector25~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector39~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(8),
	datac => \I_ads8330_interface|adc_data\(8),
	datad => \I_ads8330_interface|Selector25~0_combout\,
	combout => \I_ads8330_interface|Selector31~0_combout\);

-- Location: LCCOMB_X16_Y35_N4
\I_ads8330_interface|Selector28~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector28~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(11)) # ((\I_ads8330_interface|adc_data\(11) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(11) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(11),
	datac => \I_ads8330_interface|adc_data\(11),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector28~0_combout\);

-- Location: LCCOMB_X17_Y35_N20
\I_ads8330_interface|Selector32~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector32~0_combout\ = (\I_ads8330_interface|Selector39~0_combout\ & ((\I_ads8330_interface|adc_data\(7)) # ((\I_ads8330_interface|adc_data_t\(7) & \I_ads8330_interface|Selector25~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector39~0_combout\ & (\I_ads8330_interface|adc_data_t\(7) & ((\I_ads8330_interface|Selector25~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector39~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(7),
	datac => \I_ads8330_interface|adc_data\(7),
	datad => \I_ads8330_interface|Selector25~0_combout\,
	combout => \I_ads8330_interface|Selector32~0_combout\);

-- Location: LCCOMB_X17_Y35_N24
\I_ads8330_interface|Selector33~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector33~0_combout\ = (\I_ads8330_interface|Selector39~0_combout\ & ((\I_ads8330_interface|adc_data\(6)) # ((\I_ads8330_interface|adc_data_t\(6) & \I_ads8330_interface|Selector25~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector39~0_combout\ & (\I_ads8330_interface|adc_data_t\(6) & ((\I_ads8330_interface|Selector25~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector39~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(6),
	datac => \I_ads8330_interface|adc_data\(6),
	datad => \I_ads8330_interface|Selector25~0_combout\,
	combout => \I_ads8330_interface|Selector33~0_combout\);

-- Location: LCCOMB_X16_Y35_N30
\I_ads8330_interface|Selector23~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector23~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(16)) # ((\I_ads8330_interface|adc_data\(16) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(16) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(16),
	datac => \I_ads8330_interface|adc_data\(16),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector23~0_combout\);

-- Location: LCCOMB_X16_Y35_N14
\I_ads8330_interface|Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector7~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(15)) # ((\I_ads8330_interface|adc_data_t\(14) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(14) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(14),
	datac => \I_ads8330_interface|adc_data_t\(15),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector7~0_combout\);

-- Location: LCCOMB_X17_Y35_N14
\I_ads8330_interface|Selector15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector15~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(7)) # ((\I_ads8330_interface|Selector8~0_combout\ & \I_ads8330_interface|adc_data_t\(6))))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|Selector8~0_combout\ & ((\I_ads8330_interface|adc_data_t\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(7),
	datad => \I_ads8330_interface|adc_data_t\(6),
	combout => \I_ads8330_interface|Selector15~0_combout\);

-- Location: LCCOMB_X17_Y35_N18
\I_ads8330_interface|Selector16~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector16~0_combout\ = (\I_ads8330_interface|adc_data_t\(5) & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(6) & \I_ads8330_interface|Selector8~1_combout\)))) # 
-- (!\I_ads8330_interface|adc_data_t\(5) & (((\I_ads8330_interface|adc_data_t\(6) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|adc_data_t\(5),
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(6),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector16~0_combout\);

-- Location: LCCOMB_X16_Y35_N22
\I_ads8330_interface|Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector6~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(16)) # ((\I_ads8330_interface|adc_data_t\(15) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(15) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(15),
	datac => \I_ads8330_interface|adc_data_t\(16),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector6~0_combout\);

-- Location: LCCOMB_X17_Y35_N12
\I_ads8330_interface|Selector18~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector18~0_combout\ = (\I_ads8330_interface|adc_data_t\(3) & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(4) & \I_ads8330_interface|Selector8~1_combout\)))) # 
-- (!\I_ads8330_interface|adc_data_t\(3) & (((\I_ads8330_interface|adc_data_t\(4) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|adc_data_t\(3),
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(4),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector18~0_combout\);

-- Location: LCCOMB_X17_Y35_N22
\I_ads8330_interface|Selector19~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector19~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(3)) # ((\I_ads8330_interface|Selector8~0_combout\ & \I_ads8330_interface|adc_data_t\(2))))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|Selector8~0_combout\ & ((\I_ads8330_interface|adc_data_t\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(3),
	datad => \I_ads8330_interface|adc_data_t\(2),
	combout => \I_ads8330_interface|Selector19~0_combout\);

-- Location: LCCOMB_X17_Y35_N16
\I_ads8330_interface|Selector20~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector20~0_combout\ = (\I_ads8330_interface|adc_data_t\(1) & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(2) & \I_ads8330_interface|Selector8~1_combout\)))) # 
-- (!\I_ads8330_interface|adc_data_t\(1) & (((\I_ads8330_interface|adc_data_t\(2) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|adc_data_t\(1),
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(2),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector20~0_combout\);

-- Location: LCCOMB_X17_Y35_N26
\I_ads8330_interface|Selector21~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector21~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(1)) # ((\I_ads8330_interface|Selector8~0_combout\ & \I_ads8330_interface|adc_data_t\(0))))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|Selector8~0_combout\ & ((\I_ads8330_interface|adc_data_t\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(1),
	datad => \I_ads8330_interface|adc_data_t\(0),
	combout => \I_ads8330_interface|Selector21~0_combout\);

-- Location: LCCOMB_X17_Y37_N10
\I_ad5441_interface_1|count_2~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_2~7_combout\ = (((!\I_ad5441_interface_1|next_state.data_transfer~q\) # (!\I_ad5441_interface_1|Add0~0_combout\)) # (!\SYS_RESET~input_o\)) # (!\I_power_on_reset|reset_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datab => \SYS_RESET~input_o\,
	datac => \I_ad5441_interface_1|Add0~0_combout\,
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|count_2~7_combout\);

-- Location: IOIBUF_X0_Y40_N1
\AD_SDO~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_AD_SDO,
	o => \AD_SDO~input_o\);

-- Location: IOOBUF_X0_Y36_N16
\AD_CONVST~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ads8330_interface|convst_n_t~q\,
	devoe => ww_devoe,
	o => \AD_CONVST~output_o\);

-- Location: IOOBUF_X0_Y39_N9
\AD_SCLK~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ads8330_interface|sclk_t~q\,
	devoe => ww_devoe,
	o => \AD_SCLK~output_o\);

-- Location: IOOBUF_X0_Y38_N23
\AD_CS~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ads8330_interface|cs_n_t~q\,
	devoe => ww_devoe,
	o => \AD_CS~output_o\);

-- Location: IOOBUF_X0_Y41_N23
\AD_SDI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ads8330_interface|sdi_t~q\,
	devoe => ww_devoe,
	o => \AD_SDI~output_o\);

-- Location: IOOBUF_X61_Y0_N30
\DA_CLK~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \DA_CLK~output_o\);

-- Location: IOOBUF_X54_Y0_N30
\DA1_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA1_LD~output_o\);

-- Location: IOOBUF_X54_Y0_N23
\DA1_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA1_SRI~output_o\);

-- Location: IOOBUF_X45_Y0_N23
\DA2_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_2|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA2_LD~output_o\);

-- Location: IOOBUF_X45_Y0_N16
\DA2_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA2_SRI~output_o\);

-- Location: IOOBUF_X43_Y0_N30
\DA3_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_3|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA3_LD~output_o\);

-- Location: IOOBUF_X48_Y0_N23
\DA3_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA3_SRI~output_o\);

-- Location: IOOBUF_X43_Y0_N16
\DA4_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_4|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA4_LD~output_o\);

-- Location: IOOBUF_X43_Y0_N9
\DA4_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA4_SRI~output_o\);

-- Location: IOOBUF_X38_Y0_N16
\DA5_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_5|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA5_LD~output_o\);

-- Location: IOOBUF_X38_Y0_N9
\DA5_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA5_SRI~output_o\);

-- Location: IOOBUF_X38_Y0_N30
\DA6_LD~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_6|dac_ld_n_t~q\,
	devoe => ww_devoe,
	o => \DA6_LD~output_o\);

-- Location: IOOBUF_X38_Y0_N23
\DA6_SRI~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \I_ad5441_interface_1|dac_sri_t~q\,
	devoe => ww_devoe,
	o => \DA6_SRI~output_o\);

-- Location: IOOBUF_X52_Y0_N2
\LED[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LED[0]~output_o\);

-- Location: IOOBUF_X56_Y0_N2
\LED[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LED[1]~output_o\);

-- Location: IOOBUF_X59_Y0_N30
\LED[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LED[2]~output_o\);

-- Location: IOOBUF_X54_Y0_N16
\LED[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \LED[3]~output_o\);

-- Location: IOIBUF_X0_Y21_N8
\CLKY2~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLKY2,
	o => \CLKY2~input_o\);

-- Location: CLKCTRL_G2
\CLKY2~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLKY2~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLKY2~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y39_N1
\SYS_RESET~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SYS_RESET,
	o => \SYS_RESET~input_o\);

-- Location: LCCOMB_X14_Y36_N2
\I_power_on_reset|count[1]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[1]~15_combout\ = (\I_power_on_reset|count\(0) & (\I_power_on_reset|count\(1) $ (VCC))) # (!\I_power_on_reset|count\(0) & (\I_power_on_reset|count\(1) & VCC))
-- \I_power_on_reset|count[1]~16\ = CARRY((\I_power_on_reset|count\(0) & \I_power_on_reset|count\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(0),
	datab => \I_power_on_reset|count\(1),
	datad => VCC,
	combout => \I_power_on_reset|count[1]~15_combout\,
	cout => \I_power_on_reset|count[1]~16\);

-- Location: FF_X14_Y36_N3
\I_power_on_reset|count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[1]~15_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(1));

-- Location: LCCOMB_X14_Y36_N4
\I_power_on_reset|count[2]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[2]~17_combout\ = (\I_power_on_reset|count\(2) & (!\I_power_on_reset|count[1]~16\)) # (!\I_power_on_reset|count\(2) & ((\I_power_on_reset|count[1]~16\) # (GND)))
-- \I_power_on_reset|count[2]~18\ = CARRY((!\I_power_on_reset|count[1]~16\) # (!\I_power_on_reset|count\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(2),
	datad => VCC,
	cin => \I_power_on_reset|count[1]~16\,
	combout => \I_power_on_reset|count[2]~17_combout\,
	cout => \I_power_on_reset|count[2]~18\);

-- Location: FF_X14_Y36_N5
\I_power_on_reset|count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[2]~17_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(2));

-- Location: LCCOMB_X14_Y36_N8
\I_power_on_reset|count[4]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[4]~21_combout\ = (\I_power_on_reset|count\(4) & (!\I_power_on_reset|count[3]~20\)) # (!\I_power_on_reset|count\(4) & ((\I_power_on_reset|count[3]~20\) # (GND)))
-- \I_power_on_reset|count[4]~22\ = CARRY((!\I_power_on_reset|count[3]~20\) # (!\I_power_on_reset|count\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(4),
	datad => VCC,
	cin => \I_power_on_reset|count[3]~20\,
	combout => \I_power_on_reset|count[4]~21_combout\,
	cout => \I_power_on_reset|count[4]~22\);

-- Location: FF_X14_Y36_N9
\I_power_on_reset|count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[4]~21_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(4));

-- Location: LCCOMB_X14_Y36_N10
\I_power_on_reset|count[5]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[5]~23_combout\ = (\I_power_on_reset|count\(5) & (\I_power_on_reset|count[4]~22\ $ (GND))) # (!\I_power_on_reset|count\(5) & (!\I_power_on_reset|count[4]~22\ & VCC))
-- \I_power_on_reset|count[5]~24\ = CARRY((\I_power_on_reset|count\(5) & !\I_power_on_reset|count[4]~22\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(5),
	datad => VCC,
	cin => \I_power_on_reset|count[4]~22\,
	combout => \I_power_on_reset|count[5]~23_combout\,
	cout => \I_power_on_reset|count[5]~24\);

-- Location: LCCOMB_X14_Y36_N12
\I_power_on_reset|count[6]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[6]~25_combout\ = (\I_power_on_reset|count\(6) & (!\I_power_on_reset|count[5]~24\)) # (!\I_power_on_reset|count\(6) & ((\I_power_on_reset|count[5]~24\) # (GND)))
-- \I_power_on_reset|count[6]~26\ = CARRY((!\I_power_on_reset|count[5]~24\) # (!\I_power_on_reset|count\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(6),
	datad => VCC,
	cin => \I_power_on_reset|count[5]~24\,
	combout => \I_power_on_reset|count[6]~25_combout\,
	cout => \I_power_on_reset|count[6]~26\);

-- Location: LCCOMB_X14_Y36_N14
\I_power_on_reset|count[7]~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[7]~27_combout\ = (\I_power_on_reset|count\(7) & (\I_power_on_reset|count[6]~26\ $ (GND))) # (!\I_power_on_reset|count\(7) & (!\I_power_on_reset|count[6]~26\ & VCC))
-- \I_power_on_reset|count[7]~28\ = CARRY((\I_power_on_reset|count\(7) & !\I_power_on_reset|count[6]~26\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(7),
	datad => VCC,
	cin => \I_power_on_reset|count[6]~26\,
	combout => \I_power_on_reset|count[7]~27_combout\,
	cout => \I_power_on_reset|count[7]~28\);

-- Location: FF_X14_Y36_N15
\I_power_on_reset|count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[7]~27_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(7));

-- Location: LCCOMB_X14_Y36_N16
\I_power_on_reset|count[8]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[8]~29_combout\ = (\I_power_on_reset|count\(8) & (!\I_power_on_reset|count[7]~28\)) # (!\I_power_on_reset|count\(8) & ((\I_power_on_reset|count[7]~28\) # (GND)))
-- \I_power_on_reset|count[8]~30\ = CARRY((!\I_power_on_reset|count[7]~28\) # (!\I_power_on_reset|count\(8)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(8),
	datad => VCC,
	cin => \I_power_on_reset|count[7]~28\,
	combout => \I_power_on_reset|count[8]~29_combout\,
	cout => \I_power_on_reset|count[8]~30\);

-- Location: FF_X14_Y36_N17
\I_power_on_reset|count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[8]~29_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(8));

-- Location: LCCOMB_X14_Y36_N18
\I_power_on_reset|count[9]~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[9]~31_combout\ = (\I_power_on_reset|count\(9) & (\I_power_on_reset|count[8]~30\ $ (GND))) # (!\I_power_on_reset|count\(9) & (!\I_power_on_reset|count[8]~30\ & VCC))
-- \I_power_on_reset|count[9]~32\ = CARRY((\I_power_on_reset|count\(9) & !\I_power_on_reset|count[8]~30\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(9),
	datad => VCC,
	cin => \I_power_on_reset|count[8]~30\,
	combout => \I_power_on_reset|count[9]~31_combout\,
	cout => \I_power_on_reset|count[9]~32\);

-- Location: FF_X14_Y36_N19
\I_power_on_reset|count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[9]~31_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(9));

-- Location: LCCOMB_X14_Y36_N20
\I_power_on_reset|count[10]~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[10]~33_combout\ = (\I_power_on_reset|count\(10) & (!\I_power_on_reset|count[9]~32\)) # (!\I_power_on_reset|count\(10) & ((\I_power_on_reset|count[9]~32\) # (GND)))
-- \I_power_on_reset|count[10]~34\ = CARRY((!\I_power_on_reset|count[9]~32\) # (!\I_power_on_reset|count\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(10),
	datad => VCC,
	cin => \I_power_on_reset|count[9]~32\,
	combout => \I_power_on_reset|count[10]~33_combout\,
	cout => \I_power_on_reset|count[10]~34\);

-- Location: FF_X14_Y36_N21
\I_power_on_reset|count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[10]~33_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(10));

-- Location: LCCOMB_X14_Y36_N24
\I_power_on_reset|count[12]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[12]~37_combout\ = (\I_power_on_reset|count\(12) & (!\I_power_on_reset|count[11]~36\)) # (!\I_power_on_reset|count\(12) & ((\I_power_on_reset|count[11]~36\) # (GND)))
-- \I_power_on_reset|count[12]~38\ = CARRY((!\I_power_on_reset|count[11]~36\) # (!\I_power_on_reset|count\(12)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(12),
	datad => VCC,
	cin => \I_power_on_reset|count[11]~36\,
	combout => \I_power_on_reset|count[12]~37_combout\,
	cout => \I_power_on_reset|count[12]~38\);

-- Location: FF_X14_Y36_N25
\I_power_on_reset|count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[12]~37_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(12));

-- Location: LCCOMB_X14_Y36_N28
\I_power_on_reset|count[14]~41\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[14]~41_combout\ = (\I_power_on_reset|count\(14) & (!\I_power_on_reset|count[13]~40\)) # (!\I_power_on_reset|count\(14) & ((\I_power_on_reset|count[13]~40\) # (GND)))
-- \I_power_on_reset|count[14]~42\ = CARRY((!\I_power_on_reset|count[13]~40\) # (!\I_power_on_reset|count\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(14),
	datad => VCC,
	cin => \I_power_on_reset|count[13]~40\,
	combout => \I_power_on_reset|count[14]~41_combout\,
	cout => \I_power_on_reset|count[14]~42\);

-- Location: FF_X14_Y36_N29
\I_power_on_reset|count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[14]~41_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(14));

-- Location: FF_X14_Y36_N13
\I_power_on_reset|count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[6]~25_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(6));

-- Location: FF_X14_Y36_N11
\I_power_on_reset|count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[5]~23_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(5));

-- Location: LCCOMB_X15_Y36_N18
\I_power_on_reset|LessThan0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|LessThan0~0_combout\ = (!\I_power_on_reset|count\(7) & (((!\I_power_on_reset|count\(4) & !\I_power_on_reset|count\(5))) # (!\I_power_on_reset|count\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(4),
	datab => \I_power_on_reset|count\(6),
	datac => \I_power_on_reset|count\(5),
	datad => \I_power_on_reset|count\(7),
	combout => \I_power_on_reset|LessThan0~0_combout\);

-- Location: LCCOMB_X15_Y36_N4
\I_power_on_reset|LessThan0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|LessThan0~1_combout\ = ((\I_power_on_reset|LessThan0~0_combout\) # (!\I_power_on_reset|count\(8))) # (!\I_power_on_reset|count\(9))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|count\(9),
	datac => \I_power_on_reset|count\(8),
	datad => \I_power_on_reset|LessThan0~0_combout\,
	combout => \I_power_on_reset|LessThan0~1_combout\);

-- Location: LCCOMB_X14_Y36_N30
\I_power_on_reset|count[15]~43\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|count[15]~43_combout\ = \I_power_on_reset|count\(15) $ (!\I_power_on_reset|count[14]~42\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110100101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|count\(15),
	cin => \I_power_on_reset|count[14]~42\,
	combout => \I_power_on_reset|count[15]~43_combout\);

-- Location: FF_X14_Y36_N31
\I_power_on_reset|count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|count[15]~43_combout\,
	ena => \I_power_on_reset|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|count\(15));

-- Location: LCCOMB_X15_Y36_N0
\I_power_on_reset|LessThan0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|LessThan0~3_combout\ = (((\I_power_on_reset|LessThan0~2_combout\ & \I_power_on_reset|LessThan0~1_combout\)) # (!\I_power_on_reset|count\(15))) # (!\I_power_on_reset|count\(14))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|LessThan0~2_combout\,
	datab => \I_power_on_reset|count\(14),
	datac => \I_power_on_reset|LessThan0~1_combout\,
	datad => \I_power_on_reset|count\(15),
	combout => \I_power_on_reset|LessThan0~3_combout\);

-- Location: LCCOMB_X15_Y36_N8
\I_power_on_reset|reset_t~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_power_on_reset|reset_t~0_combout\ = !\I_power_on_reset|LessThan0~3_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \I_power_on_reset|LessThan0~3_combout\,
	combout => \I_power_on_reset|reset_t~0_combout\);

-- Location: FF_X15_Y36_N9
\I_power_on_reset|reset_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_power_on_reset|reset_t~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_power_on_reset|reset_t~q\);

-- Location: LCCOMB_X16_Y36_N28
reset : cycloneive_lcell_comb
-- Equation(s):
-- \reset~combout\ = (!\I_power_on_reset|reset_t~q\) # (!\SYS_RESET~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \SYS_RESET~input_o\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \reset~combout\);

-- Location: LCCOMB_X17_Y36_N14
\I_ads8330_interface|count_1[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[1]~9_combout\ = (\I_ads8330_interface|count_1\(1) & (!\I_ads8330_interface|count_1[0]~8\)) # (!\I_ads8330_interface|count_1\(1) & ((\I_ads8330_interface|count_1[0]~8\) # (GND)))
-- \I_ads8330_interface|count_1[1]~10\ = CARRY((!\I_ads8330_interface|count_1[0]~8\) # (!\I_ads8330_interface|count_1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_1\(1),
	datad => VCC,
	cin => \I_ads8330_interface|count_1[0]~8\,
	combout => \I_ads8330_interface|count_1[1]~9_combout\,
	cout => \I_ads8330_interface|count_1[1]~10\);

-- Location: LCCOMB_X16_Y36_N12
\I_ads8330_interface|next_state.idle~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state.idle~0_combout\ = !\reset~combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \reset~combout\,
	combout => \I_ads8330_interface|next_state.idle~0_combout\);

-- Location: FF_X16_Y36_N13
\I_ads8330_interface|next_state.idle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state.idle~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|next_state.idle~q\);

-- Location: LCCOMB_X17_Y36_N18
\I_ads8330_interface|count_1[3]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[3]~17_combout\ = (\I_ads8330_interface|count_1\(3) & (!\I_ads8330_interface|count_1[2]~16\)) # (!\I_ads8330_interface|count_1\(3) & ((\I_ads8330_interface|count_1[2]~16\) # (GND)))
-- \I_ads8330_interface|count_1[3]~18\ = CARRY((!\I_ads8330_interface|count_1[2]~16\) # (!\I_ads8330_interface|count_1\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_1\(3),
	datad => VCC,
	cin => \I_ads8330_interface|count_1[2]~16\,
	combout => \I_ads8330_interface|count_1[3]~17_combout\,
	cout => \I_ads8330_interface|count_1[3]~18\);

-- Location: LCCOMB_X17_Y36_N20
\I_ads8330_interface|count_1[4]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[4]~19_combout\ = (\I_ads8330_interface|count_1\(4) & (\I_ads8330_interface|count_1[3]~18\ $ (GND))) # (!\I_ads8330_interface|count_1\(4) & (!\I_ads8330_interface|count_1[3]~18\ & VCC))
-- \I_ads8330_interface|count_1[4]~20\ = CARRY((\I_ads8330_interface|count_1\(4) & !\I_ads8330_interface|count_1[3]~18\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_1\(4),
	datad => VCC,
	cin => \I_ads8330_interface|count_1[3]~18\,
	combout => \I_ads8330_interface|count_1[4]~19_combout\,
	cout => \I_ads8330_interface|count_1[4]~20\);

-- Location: FF_X17_Y36_N21
\I_ads8330_interface|count_1[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[4]~19_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(4));

-- Location: LCCOMB_X17_Y36_N22
\I_ads8330_interface|count_1[5]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[5]~21_combout\ = \I_ads8330_interface|count_1\(5) $ (\I_ads8330_interface|count_1[4]~20\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_1\(5),
	cin => \I_ads8330_interface|count_1[4]~20\,
	combout => \I_ads8330_interface|count_1[5]~21_combout\);

-- Location: FF_X17_Y36_N23
\I_ads8330_interface|count_1[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[5]~21_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(5));

-- Location: LCCOMB_X16_Y36_N22
\I_ads8330_interface|next_state~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~11_combout\ = (\I_ads8330_interface|Equal0~0_combout\ & (\I_ads8330_interface|count_1\(2) & (!\I_ads8330_interface|next_state~7_combout\ & !\I_ads8330_interface|count_1\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Equal0~0_combout\,
	datab => \I_ads8330_interface|count_1\(2),
	datac => \I_ads8330_interface|next_state~7_combout\,
	datad => \I_ads8330_interface|count_1\(5),
	combout => \I_ads8330_interface|next_state~11_combout\);

-- Location: FF_X16_Y36_N23
\I_ads8330_interface|next_state.issue_cs\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|next_state.issue_cs~q\);

-- Location: LCCOMB_X16_Y36_N6
\I_ads8330_interface|count_1[5]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[5]~13_combout\ = (((\I_ads8330_interface|next_state.issue_cs~q\) # (!\I_power_on_reset|reset_t~q\)) # (!\I_ads8330_interface|next_state.idle~q\)) # (!\SYS_RESET~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SYS_RESET~input_o\,
	datab => \I_ads8330_interface|next_state.idle~q\,
	datac => \I_ads8330_interface|next_state.issue_cs~q\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \I_ads8330_interface|count_1[5]~13_combout\);

-- Location: LCCOMB_X17_Y36_N4
\I_ads8330_interface|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Equal0~0_combout\ = (\I_ads8330_interface|count_1\(0) & (!\I_ads8330_interface|count_1\(4) & (!\I_ads8330_interface|count_1\(1) & !\I_ads8330_interface|count_1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_1\(0),
	datab => \I_ads8330_interface|count_1\(4),
	datac => \I_ads8330_interface|count_1\(1),
	datad => \I_ads8330_interface|count_1\(3),
	combout => \I_ads8330_interface|Equal0~0_combout\);

-- Location: LCCOMB_X17_Y36_N24
\I_ads8330_interface|Equal1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Equal1~0_combout\ = (\I_ads8330_interface|count_1\(5) & (\I_ads8330_interface|Equal0~0_combout\ & !\I_ads8330_interface|count_1\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_1\(5),
	datac => \I_ads8330_interface|Equal0~0_combout\,
	datad => \I_ads8330_interface|count_1\(2),
	combout => \I_ads8330_interface|Equal1~0_combout\);

-- Location: LCCOMB_X17_Y36_N8
\I_ads8330_interface|count_1[5]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[5]~11_combout\ = (!\I_ads8330_interface|next_state.issue_convst~q\ & ((\I_ads8330_interface|Selector25~0_combout\) # ((!\I_ads8330_interface|next_state.wait_state~q\ & \I_ads8330_interface|Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.wait_state~q\,
	datab => \I_ads8330_interface|next_state.issue_convst~q\,
	datac => \I_ads8330_interface|Selector25~0_combout\,
	datad => \I_ads8330_interface|Equal1~0_combout\,
	combout => \I_ads8330_interface|count_1[5]~11_combout\);

-- Location: LCCOMB_X17_Y36_N10
\I_ads8330_interface|count_1[5]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[5]~12_combout\ = (\I_ads8330_interface|next_state.issue_convst~q\ & (\I_ads8330_interface|Equal0~0_combout\ & (!\I_ads8330_interface|count_1\(5) & \I_ads8330_interface|count_1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.issue_convst~q\,
	datab => \I_ads8330_interface|Equal0~0_combout\,
	datac => \I_ads8330_interface|count_1\(5),
	datad => \I_ads8330_interface|count_1\(2),
	combout => \I_ads8330_interface|count_1[5]~12_combout\);

-- Location: LCCOMB_X17_Y36_N28
\I_ads8330_interface|count_1[5]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[5]~14_combout\ = (\I_ads8330_interface|count_1[5]~13_combout\) # ((\I_ads8330_interface|count_1[5]~11_combout\) # (\I_ads8330_interface|count_1[5]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_1[5]~13_combout\,
	datac => \I_ads8330_interface|count_1[5]~11_combout\,
	datad => \I_ads8330_interface|count_1[5]~12_combout\,
	combout => \I_ads8330_interface|count_1[5]~14_combout\);

-- Location: FF_X17_Y36_N15
\I_ads8330_interface|count_1[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[1]~9_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(1));

-- Location: LCCOMB_X17_Y36_N16
\I_ads8330_interface|count_1[2]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_1[2]~15_combout\ = (\I_ads8330_interface|count_1\(2) & (\I_ads8330_interface|count_1[1]~10\ $ (GND))) # (!\I_ads8330_interface|count_1\(2) & (!\I_ads8330_interface|count_1[1]~10\ & VCC))
-- \I_ads8330_interface|count_1[2]~16\ = CARRY((\I_ads8330_interface|count_1\(2) & !\I_ads8330_interface|count_1[1]~10\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_1\(2),
	datad => VCC,
	cin => \I_ads8330_interface|count_1[1]~10\,
	combout => \I_ads8330_interface|count_1[2]~15_combout\,
	cout => \I_ads8330_interface|count_1[2]~16\);

-- Location: FF_X17_Y36_N17
\I_ads8330_interface|count_1[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[2]~15_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(2));

-- Location: FF_X17_Y36_N19
\I_ads8330_interface|count_1[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_1[3]~17_combout\,
	sclr => \I_ads8330_interface|count_1[5]~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_1\(3));

-- Location: LCCOMB_X17_Y36_N0
\I_ads8330_interface|Equal2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Equal2~0_combout\ = (!\I_ads8330_interface|count_1\(0) & (!\I_ads8330_interface|count_1\(4) & (!\I_ads8330_interface|count_1\(1) & !\I_ads8330_interface|count_1\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|count_1\(0),
	datab => \I_ads8330_interface|count_1\(4),
	datac => \I_ads8330_interface|count_1\(1),
	datad => \I_ads8330_interface|count_1\(2),
	combout => \I_ads8330_interface|Equal2~0_combout\);

-- Location: LCCOMB_X17_Y36_N26
\I_ads8330_interface|Selector25~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector25~0_combout\ = (\I_ads8330_interface|next_state.wait_state~q\ & (\I_ads8330_interface|count_1\(3) & (!\I_ads8330_interface|count_1\(5) & \I_ads8330_interface|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.wait_state~q\,
	datab => \I_ads8330_interface|count_1\(3),
	datac => \I_ads8330_interface|count_1\(5),
	datad => \I_ads8330_interface|Equal2~0_combout\,
	combout => \I_ads8330_interface|Selector25~0_combout\);

-- Location: LCCOMB_X17_Y36_N6
\I_ads8330_interface|next_state~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~8_combout\ = (\I_ads8330_interface|next_state.issue_convst~q\ & (((\I_ads8330_interface|count_1\(5)) # (!\I_ads8330_interface|count_1\(2))) # (!\I_ads8330_interface|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.issue_convst~q\,
	datab => \I_ads8330_interface|Equal0~0_combout\,
	datac => \I_ads8330_interface|count_1\(5),
	datad => \I_ads8330_interface|count_1\(2),
	combout => \I_ads8330_interface|next_state~8_combout\);

-- Location: LCCOMB_X16_Y36_N0
\I_ads8330_interface|next_state~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~9_combout\ = (!\reset~combout\ & (((\I_ads8330_interface|Selector25~0_combout\) # (\I_ads8330_interface|next_state~8_combout\)) # (!\I_ads8330_interface|next_state.idle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.idle~q\,
	datab => \reset~combout\,
	datac => \I_ads8330_interface|Selector25~0_combout\,
	datad => \I_ads8330_interface|next_state~8_combout\,
	combout => \I_ads8330_interface|next_state~9_combout\);

-- Location: FF_X16_Y36_N1
\I_ads8330_interface|next_state.issue_convst\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|next_state.issue_convst~q\);

-- Location: LCCOMB_X16_Y36_N18
\I_ads8330_interface|next_state~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~7_combout\ = ((!\I_ads8330_interface|next_state.issue_convst~q\) # (!\SYS_RESET~input_o\)) # (!\I_power_on_reset|reset_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|next_state.issue_convst~q\,
	combout => \I_ads8330_interface|next_state~7_combout\);

-- Location: FF_X16_Y36_N19
\I_ads8330_interface|convst_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|convst_n_t~q\);

-- Location: LCCOMB_X16_Y36_N10
\I_ads8330_interface|next_state~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~10_combout\ = (!\reset~combout\ & ((\I_ads8330_interface|next_state.issue_cs~q\) # ((\I_ads8330_interface|next_state.data_transfer~q\ & !\I_ads8330_interface|Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.issue_cs~q\,
	datab => \reset~combout\,
	datac => \I_ads8330_interface|next_state.data_transfer~q\,
	datad => \I_ads8330_interface|Equal1~0_combout\,
	combout => \I_ads8330_interface|next_state~10_combout\);

-- Location: FF_X16_Y36_N11
\I_ads8330_interface|next_state.data_transfer\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|next_state.data_transfer~q\);

-- Location: LCCOMB_X16_Y36_N8
\I_ads8330_interface|sclk_t~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|sclk_t~1_combout\ = (!\I_ads8330_interface|sclk_t~q\ & \I_ads8330_interface|next_state.data_transfer~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ads8330_interface|sclk_t~q\,
	datad => \I_ads8330_interface|next_state.data_transfer~q\,
	combout => \I_ads8330_interface|sclk_t~1_combout\);

-- Location: FF_X16_Y36_N9
\I_ads8330_interface|sclk_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|sclk_t~1_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|sclk_t~q\);

-- Location: LCCOMB_X16_Y36_N4
\I_ads8330_interface|cs_n_t~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|cs_n_t~1_combout\ = (((!\I_ads8330_interface|next_state.data_transfer~q\ & !\I_ads8330_interface|next_state.issue_cs~q\)) # (!\I_power_on_reset|reset_t~q\)) # (!\SYS_RESET~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101011111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SYS_RESET~input_o\,
	datab => \I_ads8330_interface|next_state.data_transfer~q\,
	datac => \I_ads8330_interface|next_state.issue_cs~q\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \I_ads8330_interface|cs_n_t~1_combout\);

-- Location: FF_X16_Y36_N5
\I_ads8330_interface|cs_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|cs_n_t~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|cs_n_t~q\);

-- Location: LCCOMB_X11_Y36_N16
\I_ads8330_interface|count_2[0]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[0]~5_combout\ = \I_ads8330_interface|count_2\(0) $ (VCC)
-- \I_ads8330_interface|count_2[0]~6\ = CARRY(\I_ads8330_interface|count_2\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_2\(0),
	datad => VCC,
	combout => \I_ads8330_interface|count_2[0]~5_combout\,
	cout => \I_ads8330_interface|count_2[0]~6\);

-- Location: LCCOMB_X16_Y36_N14
\I_ads8330_interface|count_2[1]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[1]~15_combout\ = ((!\I_power_on_reset|reset_t~q\) # (!\SYS_RESET~input_o\)) # (!\I_ads8330_interface|next_state.data_transfer~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.data_transfer~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \I_ads8330_interface|count_2[1]~15_combout\);

-- Location: LCCOMB_X16_Y36_N16
\I_ads8330_interface|count_2[1]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[1]~16_combout\ = (((!\I_ads8330_interface|next_state.data_transfer~q\) # (!\SYS_RESET~input_o\)) # (!\I_ads8330_interface|sclk_t~q\)) # (!\I_power_on_reset|reset_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datab => \I_ads8330_interface|sclk_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|next_state.data_transfer~q\,
	combout => \I_ads8330_interface|count_2[1]~16_combout\);

-- Location: FF_X11_Y36_N17
\I_ads8330_interface|count_2[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_2[0]~5_combout\,
	asdata => VCC,
	sload => \I_ads8330_interface|count_2[1]~15_combout\,
	ena => \I_ads8330_interface|count_2[1]~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_2\(0));

-- Location: LCCOMB_X11_Y36_N18
\I_ads8330_interface|count_2[1]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[1]~7_combout\ = (\I_ads8330_interface|count_2\(1) & (\I_ads8330_interface|count_2[0]~6\ & VCC)) # (!\I_ads8330_interface|count_2\(1) & (!\I_ads8330_interface|count_2[0]~6\))
-- \I_ads8330_interface|count_2[1]~8\ = CARRY((!\I_ads8330_interface|count_2\(1) & !\I_ads8330_interface|count_2[0]~6\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_2\(1),
	datad => VCC,
	cin => \I_ads8330_interface|count_2[0]~6\,
	combout => \I_ads8330_interface|count_2[1]~7_combout\,
	cout => \I_ads8330_interface|count_2[1]~8\);

-- Location: LCCOMB_X11_Y36_N26
\~GND\ : cycloneive_lcell_comb
-- Equation(s):
-- \~GND~combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~GND~combout\);

-- Location: FF_X11_Y36_N19
\I_ads8330_interface|count_2[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_2[1]~7_combout\,
	asdata => \~GND~combout\,
	sload => \I_ads8330_interface|count_2[1]~15_combout\,
	ena => \I_ads8330_interface|count_2[1]~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_2\(1));

-- Location: LCCOMB_X11_Y36_N20
\I_ads8330_interface|count_2[2]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[2]~9_combout\ = (\I_ads8330_interface|count_2\(2) & ((GND) # (!\I_ads8330_interface|count_2[1]~8\))) # (!\I_ads8330_interface|count_2\(2) & (\I_ads8330_interface|count_2[1]~8\ $ (GND)))
-- \I_ads8330_interface|count_2[2]~10\ = CARRY((\I_ads8330_interface|count_2\(2)) # (!\I_ads8330_interface|count_2[1]~8\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|count_2\(2),
	datad => VCC,
	cin => \I_ads8330_interface|count_2[1]~8\,
	combout => \I_ads8330_interface|count_2[2]~9_combout\,
	cout => \I_ads8330_interface|count_2[2]~10\);

-- Location: FF_X11_Y36_N21
\I_ads8330_interface|count_2[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_2[2]~9_combout\,
	asdata => \~GND~combout\,
	sload => \I_ads8330_interface|count_2[1]~15_combout\,
	ena => \I_ads8330_interface|count_2[1]~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_2\(2));

-- Location: LCCOMB_X11_Y36_N24
\I_ads8330_interface|count_2[4]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|count_2[4]~13_combout\ = \I_ads8330_interface|count_2[3]~12\ $ (\I_ads8330_interface|count_2\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \I_ads8330_interface|count_2\(4),
	cin => \I_ads8330_interface|count_2[3]~12\,
	combout => \I_ads8330_interface|count_2[4]~13_combout\);

-- Location: FF_X11_Y36_N25
\I_ads8330_interface|count_2[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|count_2[4]~13_combout\,
	asdata => VCC,
	sload => \I_ads8330_interface|count_2[1]~15_combout\,
	ena => \I_ads8330_interface|count_2[1]~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|count_2\(4));

-- Location: LCCOMB_X12_Y36_N0
\I_ads8330_interface|sdi_t~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|sdi_t~1_combout\ = (\I_ads8330_interface|sclk_t~q\ & (((\I_ads8330_interface|sdi_t~q\)))) # (!\I_ads8330_interface|sclk_t~q\ & ((\I_ads8330_interface|sdi_t~0_combout\) # ((\I_ads8330_interface|count_2\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|sdi_t~0_combout\,
	datab => \I_ads8330_interface|count_2\(4),
	datac => \I_ads8330_interface|sdi_t~q\,
	datad => \I_ads8330_interface|sclk_t~q\,
	combout => \I_ads8330_interface|sdi_t~1_combout\);

-- Location: FF_X12_Y36_N1
\I_ads8330_interface|sdi_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|sdi_t~1_combout\,
	asdata => \~GND~combout\,
	sclr => \reset~combout\,
	sload => \I_ads8330_interface|ALT_INV_next_state.data_transfer~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|sdi_t~q\);

-- Location: LCCOMB_X16_Y36_N26
\I_ad5441_interface_1|next_state~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|next_state~8_combout\ = (!\I_ad5441_interface_1|next_state.issue_ld~q\ & (!\reset~combout\ & ((\I_ads8330_interface|data_val~q\) # (\I_ad5441_interface_1|next_state.idle~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|data_val~q\,
	datab => \I_ad5441_interface_1|next_state.issue_ld~q\,
	datac => \I_ad5441_interface_1|next_state.idle~q\,
	datad => \reset~combout\,
	combout => \I_ad5441_interface_1|next_state~8_combout\);

-- Location: FF_X16_Y36_N27
\I_ad5441_interface_1|next_state.idle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|next_state~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|next_state.idle~q\);

-- Location: LCCOMB_X15_Y35_N24
\I_ads8330_interface|data_val~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|data_val~0_combout\ = (\I_ads8330_interface|data_val~q\) # ((\I_ads8330_interface|Equal2~0_combout\ & (\I_ads8330_interface|count_1\(3) & !\I_ads8330_interface|count_1\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Equal2~0_combout\,
	datab => \I_ads8330_interface|count_1\(3),
	datac => \I_ads8330_interface|data_val~q\,
	datad => \I_ads8330_interface|count_1\(5),
	combout => \I_ads8330_interface|data_val~0_combout\);

-- Location: LCCOMB_X17_Y36_N2
\I_ads8330_interface|next_state~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~12_combout\ = (\I_ads8330_interface|next_state.wait_state~q\ & (((\I_ads8330_interface|count_1\(5)) # (!\I_ads8330_interface|Equal2~0_combout\)) # (!\I_ads8330_interface|count_1\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.wait_state~q\,
	datab => \I_ads8330_interface|count_1\(3),
	datac => \I_ads8330_interface|count_1\(5),
	datad => \I_ads8330_interface|Equal2~0_combout\,
	combout => \I_ads8330_interface|next_state~12_combout\);

-- Location: LCCOMB_X16_Y36_N2
\I_ads8330_interface|next_state~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|next_state~13_combout\ = (!\reset~combout\ & ((\I_ads8330_interface|next_state~12_combout\) # ((\I_ads8330_interface|next_state.data_transfer~q\ & \I_ads8330_interface|Equal1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.data_transfer~q\,
	datab => \I_ads8330_interface|Equal1~0_combout\,
	datac => \reset~combout\,
	datad => \I_ads8330_interface|next_state~12_combout\,
	combout => \I_ads8330_interface|next_state~13_combout\);

-- Location: FF_X16_Y36_N3
\I_ads8330_interface|next_state.wait_state\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|next_state~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|next_state.wait_state~q\);

-- Location: FF_X15_Y35_N25
\I_ads8330_interface|data_val\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|data_val~0_combout\,
	asdata => \~GND~combout\,
	sclr => \reset~combout\,
	sload => \I_ads8330_interface|ALT_INV_next_state.wait_state~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|data_val~q\);

-- Location: LCCOMB_X15_Y37_N0
\I_ad5441_interface_1|count_1[0]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[0]~5_combout\ = \I_ad5441_interface_1|count_1\(0) $ (VCC)
-- \I_ad5441_interface_1|count_1[0]~6\ = CARRY(\I_ad5441_interface_1|count_1\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_1\(0),
	datad => VCC,
	combout => \I_ad5441_interface_1|count_1[0]~5_combout\,
	cout => \I_ad5441_interface_1|count_1[0]~6\);

-- Location: LCCOMB_X15_Y37_N2
\I_ad5441_interface_1|count_1[1]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[1]~7_combout\ = (\I_ad5441_interface_1|count_1\(1) & (!\I_ad5441_interface_1|count_1[0]~6\)) # (!\I_ad5441_interface_1|count_1\(1) & ((\I_ad5441_interface_1|count_1[0]~6\) # (GND)))
-- \I_ad5441_interface_1|count_1[1]~8\ = CARRY((!\I_ad5441_interface_1|count_1[0]~6\) # (!\I_ad5441_interface_1|count_1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_1\(1),
	datad => VCC,
	cin => \I_ad5441_interface_1|count_1[0]~6\,
	combout => \I_ad5441_interface_1|count_1[1]~7_combout\,
	cout => \I_ad5441_interface_1|count_1[1]~8\);

-- Location: LCCOMB_X15_Y37_N4
\I_ad5441_interface_1|count_1[2]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[2]~9_combout\ = (\I_ad5441_interface_1|count_1\(2) & (\I_ad5441_interface_1|count_1[1]~8\ $ (GND))) # (!\I_ad5441_interface_1|count_1\(2) & (!\I_ad5441_interface_1|count_1[1]~8\ & VCC))
-- \I_ad5441_interface_1|count_1[2]~10\ = CARRY((\I_ad5441_interface_1|count_1\(2) & !\I_ad5441_interface_1|count_1[1]~8\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_1\(2),
	datad => VCC,
	cin => \I_ad5441_interface_1|count_1[1]~8\,
	combout => \I_ad5441_interface_1|count_1[2]~9_combout\,
	cout => \I_ad5441_interface_1|count_1[2]~10\);

-- Location: FF_X15_Y37_N5
\I_ad5441_interface_1|count_1[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_1[2]~9_combout\,
	sclr => \I_ad5441_interface_1|count_1[2]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_1\(2));

-- Location: LCCOMB_X15_Y37_N8
\I_ad5441_interface_1|count_1[4]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[4]~14_combout\ = \I_ad5441_interface_1|count_1\(4) $ (!\I_ad5441_interface_1|count_1[3]~12\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_1\(4),
	cin => \I_ad5441_interface_1|count_1[3]~12\,
	combout => \I_ad5441_interface_1|count_1[4]~14_combout\);

-- Location: FF_X15_Y37_N9
\I_ad5441_interface_1|count_1[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_1[4]~14_combout\,
	sclr => \I_ad5441_interface_1|count_1[2]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_1\(4));

-- Location: LCCOMB_X15_Y37_N24
\I_ad5441_interface_1|count_1[2]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_1[2]~13_combout\ = ((\reset~combout\) # ((\I_ad5441_interface_1|count_1\(4) & !\I_ad5441_interface_1|Equal0~0_combout\))) # (!\I_ad5441_interface_1|next_state.data_transfer~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datab => \I_ad5441_interface_1|count_1\(4),
	datac => \reset~combout\,
	datad => \I_ad5441_interface_1|Equal0~0_combout\,
	combout => \I_ad5441_interface_1|count_1[2]~13_combout\);

-- Location: FF_X15_Y37_N1
\I_ad5441_interface_1|count_1[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_1[0]~5_combout\,
	sclr => \I_ad5441_interface_1|count_1[2]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_1\(0));

-- Location: FF_X15_Y37_N3
\I_ad5441_interface_1|count_1[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_1[1]~7_combout\,
	sclr => \I_ad5441_interface_1|count_1[2]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_1\(1));

-- Location: LCCOMB_X15_Y37_N18
\I_ad5441_interface_1|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Equal0~0_combout\ = (\I_ad5441_interface_1|count_1\(3)) # (((!\I_ad5441_interface_1|count_1\(0)) # (!\I_ad5441_interface_1|count_1\(2))) # (!\I_ad5441_interface_1|count_1\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_1\(3),
	datab => \I_ad5441_interface_1|count_1\(1),
	datac => \I_ad5441_interface_1|count_1\(2),
	datad => \I_ad5441_interface_1|count_1\(0),
	combout => \I_ad5441_interface_1|Equal0~0_combout\);

-- Location: LCCOMB_X16_Y36_N20
\I_ad5441_interface_1|next_state~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|next_state~6_combout\ = (\I_ad5441_interface_1|next_state.data_transfer~q\ & ((\I_ad5441_interface_1|Equal0~0_combout\) # (!\I_ad5441_interface_1|count_1\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datac => \I_ad5441_interface_1|Equal0~0_combout\,
	datad => \I_ad5441_interface_1|count_1\(4),
	combout => \I_ad5441_interface_1|next_state~6_combout\);

-- Location: LCCOMB_X16_Y37_N6
\I_ad5441_interface_1|next_state~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|next_state~7_combout\ = (!\reset~combout\ & ((\I_ad5441_interface_1|next_state~6_combout\) # ((!\I_ad5441_interface_1|next_state.idle~q\ & \I_ads8330_interface|data_val~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~combout\,
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ads8330_interface|data_val~q\,
	datad => \I_ad5441_interface_1|next_state~6_combout\,
	combout => \I_ad5441_interface_1|next_state~7_combout\);

-- Location: FF_X16_Y37_N7
\I_ad5441_interface_1|next_state.data_transfer\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|next_state~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|next_state.data_transfer~q\);

-- Location: LCCOMB_X16_Y36_N24
\I_ad5441_interface_1|next_state~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|next_state~5_combout\ = (!\I_ad5441_interface_1|Equal0~0_combout\ & (!\reset~combout\ & (\I_ad5441_interface_1|next_state.data_transfer~q\ & \I_ad5441_interface_1|count_1\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|Equal0~0_combout\,
	datab => \reset~combout\,
	datac => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datad => \I_ad5441_interface_1|count_1\(4),
	combout => \I_ad5441_interface_1|next_state~5_combout\);

-- Location: FF_X16_Y36_N25
\I_ad5441_interface_1|next_state.issue_ld\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|next_state~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|next_state.issue_ld~q\);

-- Location: LCCOMB_X16_Y36_N30
\I_ad5441_interface_1|dac_ld_n_t~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|dac_ld_n_t~0_combout\ = ((!\I_power_on_reset|reset_t~q\) # (!\SYS_RESET~input_o\)) # (!\I_ad5441_interface_1|next_state.issue_ld~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|next_state.issue_ld~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \I_ad5441_interface_1|dac_ld_n_t~0_combout\);

-- Location: LCCOMB_X35_Y22_N8
\I_ad5441_interface_1|dac_ld_n_t~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|dac_ld_n_t~feeder_combout\ = \I_ad5441_interface_1|dac_ld_n_t~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	combout => \I_ad5441_interface_1|dac_ld_n_t~feeder_combout\);

-- Location: FF_X35_Y22_N9
\I_ad5441_interface_1|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|dac_ld_n_t~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_ld_n_t~q\);

-- Location: LCCOMB_X17_Y37_N20
\I_ad5441_interface_1|count_2~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_2~6_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & (!\I_ad5441_interface_1|count_2\(0) & \I_ad5441_interface_1|next_state.data_transfer~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datab => \SYS_RESET~input_o\,
	datac => \I_ad5441_interface_1|count_2\(0),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|count_2~6_combout\);

-- Location: LCCOMB_X15_Y37_N28
\I_ad5441_interface_1|count_2[1]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_2[1]~5_combout\ = (\I_ad5441_interface_1|dac_clk_t~q\) # (((!\I_ad5441_interface_1|next_state.data_transfer~q\) # (!\I_power_on_reset|reset_t~q\)) # (!\SYS_RESET~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_clk_t~q\,
	datab => \SYS_RESET~input_o\,
	datac => \I_power_on_reset|reset_t~q\,
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|count_2[1]~5_combout\);

-- Location: FF_X17_Y37_N21
\I_ad5441_interface_1|count_2[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_2~6_combout\,
	ena => \I_ad5441_interface_1|count_2[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_2\(0));

-- Location: LCCOMB_X17_Y35_N4
\I_ads8330_interface|Selector8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector8~0_combout\ = (\I_ads8330_interface|next_state.data_transfer~q\ & \I_ads8330_interface|sclk_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.data_transfer~q\,
	datad => \I_ads8330_interface|sclk_t~q\,
	combout => \I_ads8330_interface|Selector8~0_combout\);

-- Location: LCCOMB_X17_Y35_N6
\I_ads8330_interface|Selector8~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector8~1_combout\ = (\I_ads8330_interface|next_state.wait_state~q\) # ((\I_ads8330_interface|next_state.data_transfer~q\ & !\I_ads8330_interface|sclk_t~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.data_transfer~q\,
	datab => \I_ads8330_interface|sclk_t~q\,
	datad => \I_ads8330_interface|next_state.wait_state~q\,
	combout => \I_ads8330_interface|Selector8~1_combout\);

-- Location: LCCOMB_X17_Y35_N28
\I_ads8330_interface|Selector14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector14~0_combout\ = (\I_ads8330_interface|adc_data_t\(7) & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(8) & \I_ads8330_interface|Selector8~1_combout\)))) # 
-- (!\I_ads8330_interface|adc_data_t\(7) & (((\I_ads8330_interface|adc_data_t\(8) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|adc_data_t\(7),
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(8),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector14~0_combout\);

-- Location: FF_X17_Y35_N29
\I_ads8330_interface|adc_data_t[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector14~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(8));

-- Location: LCCOMB_X16_Y35_N18
\I_ads8330_interface|Selector13~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector13~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(9)) # ((\I_ads8330_interface|adc_data_t\(8) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(8) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(8),
	datac => \I_ads8330_interface|adc_data_t\(9),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector13~0_combout\);

-- Location: FF_X16_Y35_N19
\I_ads8330_interface|adc_data_t[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector13~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(9));

-- Location: LCCOMB_X16_Y35_N16
\I_ads8330_interface|Selector12~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector12~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(10)) # ((\I_ads8330_interface|adc_data_t\(9) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(9) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(9),
	datac => \I_ads8330_interface|adc_data_t\(10),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector12~0_combout\);

-- Location: FF_X16_Y35_N17
\I_ads8330_interface|adc_data_t[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector12~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(10));

-- Location: LCCOMB_X16_Y35_N20
\I_ads8330_interface|Selector11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector11~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(11)) # ((\I_ads8330_interface|adc_data_t\(10) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(10) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(10),
	datac => \I_ads8330_interface|adc_data_t\(11),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector11~0_combout\);

-- Location: FF_X16_Y35_N21
\I_ads8330_interface|adc_data_t[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector11~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(11));

-- Location: LCCOMB_X16_Y35_N28
\I_ads8330_interface|Selector10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector10~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(12)) # ((\I_ads8330_interface|adc_data_t\(11) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(11) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(11),
	datac => \I_ads8330_interface|adc_data_t\(12),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector10~0_combout\);

-- Location: FF_X16_Y35_N29
\I_ads8330_interface|adc_data_t[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector10~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(12));

-- Location: LCCOMB_X17_Y36_N30
\I_ads8330_interface|Selector39~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector39~0_combout\ = (\I_ads8330_interface|next_state~12_combout\) # ((!\I_ads8330_interface|next_state.wait_state~q\ & \I_ads8330_interface|next_state.idle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|next_state.wait_state~q\,
	datac => \I_ads8330_interface|next_state.idle~q\,
	datad => \I_ads8330_interface|next_state~12_combout\,
	combout => \I_ads8330_interface|Selector39~0_combout\);

-- Location: LCCOMB_X16_Y35_N12
\I_ads8330_interface|Selector27~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector27~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(12)) # ((\I_ads8330_interface|adc_data\(12) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(12) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(12),
	datac => \I_ads8330_interface|adc_data\(12),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector27~0_combout\);

-- Location: FF_X16_Y35_N13
\I_ads8330_interface|adc_data[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector27~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(12));

-- Location: LCCOMB_X16_Y37_N28
\dac_data~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~3_combout\ = (\I_ads8330_interface|adc_data\(12) & (\SYS_RESET~input_o\ & \I_power_on_reset|reset_t~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ads8330_interface|adc_data\(12),
	datac => \SYS_RESET~input_o\,
	datad => \I_power_on_reset|reset_t~q\,
	combout => \dac_data~3_combout\);

-- Location: LCCOMB_X17_Y35_N2
\I_ads8330_interface|Selector22~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector22~0_combout\ = (\AD_SDO~input_o\ & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(0) & \I_ads8330_interface|Selector8~1_combout\)))) # (!\AD_SDO~input_o\ & 
-- (((\I_ads8330_interface|adc_data_t\(0) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \AD_SDO~input_o\,
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(0),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector22~0_combout\);

-- Location: FF_X17_Y35_N3
\I_ads8330_interface|adc_data_t[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector22~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(0));

-- Location: LCCOMB_X17_Y35_N0
\I_ads8330_interface|Selector39~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector39~1_combout\ = (\I_ads8330_interface|Selector39~0_combout\ & ((\I_ads8330_interface|adc_data\(0)) # ((\I_ads8330_interface|adc_data_t\(0) & \I_ads8330_interface|Selector25~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector39~0_combout\ & (\I_ads8330_interface|adc_data_t\(0) & ((\I_ads8330_interface|Selector25~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector39~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(0),
	datac => \I_ads8330_interface|adc_data\(0),
	datad => \I_ads8330_interface|Selector25~0_combout\,
	combout => \I_ads8330_interface|Selector39~1_combout\);

-- Location: FF_X17_Y35_N1
\I_ads8330_interface|adc_data[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector39~1_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(0));

-- Location: LCCOMB_X16_Y37_N22
\dac_data[10]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data[10]~1_combout\ = (((\I_ads8330_interface|data_val~q\ & !\I_ads8330_interface|adc_data\(0))) # (!\SYS_RESET~input_o\)) # (!\I_power_on_reset|reset_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111111011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datab => \I_ads8330_interface|data_val~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(0),
	combout => \dac_data[10]~1_combout\);

-- Location: FF_X16_Y37_N29
\dac_data[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~3_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(7));

-- Location: LCCOMB_X16_Y37_N20
\I_ad5441_interface_1|Selector4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector4~0_combout\ = (\I_ad5441_interface_1|next_state.data_transfer~q\ & ((\I_ad5441_interface_1|dac_data_t\(8)) # ((!\I_ad5441_interface_1|next_state.idle~q\ & dac_data(7))))) # (!\I_ad5441_interface_1|next_state.data_transfer~q\ 
-- & (!\I_ad5441_interface_1|next_state.idle~q\ & ((dac_data(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(8),
	datad => dac_data(7),
	combout => \I_ad5441_interface_1|Selector4~0_combout\);

-- Location: FF_X16_Y37_N21
\I_ad5441_interface_1|dac_data_t[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector4~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(8));

-- Location: LCCOMB_X17_Y37_N18
\I_ad5441_interface_1|count_2~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_2~4_combout\ = (!\reset~combout\ & (\I_ad5441_interface_1|next_state.data_transfer~q\ & (\I_ad5441_interface_1|count_2\(1) $ (!\I_ad5441_interface_1|count_2\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~combout\,
	datab => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datac => \I_ad5441_interface_1|count_2\(1),
	datad => \I_ad5441_interface_1|count_2\(0),
	combout => \I_ad5441_interface_1|count_2~4_combout\);

-- Location: FF_X17_Y37_N19
\I_ad5441_interface_1|count_2[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_2~4_combout\,
	ena => \I_ad5441_interface_1|count_2[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_2\(1));

-- Location: LCCOMB_X17_Y37_N14
\I_ad5441_interface_1|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~0_combout\ = (\I_ad5441_interface_1|count_2\(0) & ((\I_ad5441_interface_1|dac_data_t\(9)) # ((\I_ad5441_interface_1|count_2\(1))))) # (!\I_ad5441_interface_1|count_2\(0) & (((\I_ad5441_interface_1|dac_data_t\(8) & 
-- !\I_ad5441_interface_1|count_2\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_data_t\(9),
	datab => \I_ad5441_interface_1|count_2\(0),
	datac => \I_ad5441_interface_1|dac_data_t\(8),
	datad => \I_ad5441_interface_1|count_2\(1),
	combout => \I_ad5441_interface_1|Mux0~0_combout\);

-- Location: LCCOMB_X16_Y35_N10
\I_ads8330_interface|Selector9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector9~0_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(13)) # ((\I_ads8330_interface|adc_data_t\(12) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(12) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(12),
	datac => \I_ads8330_interface|adc_data_t\(13),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector9~0_combout\);

-- Location: FF_X16_Y35_N11
\I_ads8330_interface|adc_data_t[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector9~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(13));

-- Location: LCCOMB_X16_Y35_N24
\I_ads8330_interface|Selector8~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector8~2_combout\ = (\I_ads8330_interface|Selector8~1_combout\ & ((\I_ads8330_interface|adc_data_t\(14)) # ((\I_ads8330_interface|adc_data_t\(13) & \I_ads8330_interface|Selector8~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector8~1_combout\ & (\I_ads8330_interface|adc_data_t\(13) & ((\I_ads8330_interface|Selector8~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector8~1_combout\,
	datab => \I_ads8330_interface|adc_data_t\(13),
	datac => \I_ads8330_interface|adc_data_t\(14),
	datad => \I_ads8330_interface|Selector8~0_combout\,
	combout => \I_ads8330_interface|Selector8~2_combout\);

-- Location: FF_X16_Y35_N25
\I_ads8330_interface|adc_data_t[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector8~2_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(14));

-- Location: LCCOMB_X16_Y35_N0
\I_ads8330_interface|Selector25~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector25~1_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(14)) # ((\I_ads8330_interface|adc_data\(14) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(14) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(14),
	datac => \I_ads8330_interface|adc_data\(14),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector25~1_combout\);

-- Location: FF_X16_Y35_N1
\I_ads8330_interface|adc_data[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector25~1_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(14));

-- Location: LCCOMB_X16_Y37_N8
\dac_data~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~0_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & \I_ads8330_interface|adc_data\(14)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(14),
	combout => \dac_data~0_combout\);

-- Location: FF_X16_Y37_N9
\dac_data[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~0_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(9));

-- Location: LCCOMB_X16_Y37_N0
\I_ad5441_interface_1|Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector2~0_combout\ = (\I_ad5441_interface_1|next_state.data_transfer~q\ & ((\I_ad5441_interface_1|dac_data_t\(10)) # ((!\I_ad5441_interface_1|next_state.idle~q\ & dac_data(9))))) # 
-- (!\I_ad5441_interface_1|next_state.data_transfer~q\ & (!\I_ad5441_interface_1|next_state.idle~q\ & ((dac_data(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(10),
	datad => dac_data(9),
	combout => \I_ad5441_interface_1|Selector2~0_combout\);

-- Location: FF_X16_Y37_N1
\I_ad5441_interface_1|dac_data_t[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector2~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(10));

-- Location: LCCOMB_X17_Y37_N16
\I_ad5441_interface_1|Mux0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~1_combout\ = (\I_ad5441_interface_1|Mux0~0_combout\ & ((\I_ad5441_interface_1|dac_data_t\(11)) # ((!\I_ad5441_interface_1|count_2\(1))))) # (!\I_ad5441_interface_1|Mux0~0_combout\ & (((\I_ad5441_interface_1|dac_data_t\(10) & 
-- \I_ad5441_interface_1|count_2\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_data_t\(11),
	datab => \I_ad5441_interface_1|Mux0~0_combout\,
	datac => \I_ad5441_interface_1|dac_data_t\(10),
	datad => \I_ad5441_interface_1|count_2\(1),
	combout => \I_ad5441_interface_1|Mux0~1_combout\);

-- Location: LCCOMB_X17_Y37_N6
\I_ad5441_interface_1|Add0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Add0~1_combout\ = \I_ad5441_interface_1|count_2\(2) $ (((\I_ad5441_interface_1|count_2\(0)) # (\I_ad5441_interface_1|count_2\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_2\(0),
	datac => \I_ad5441_interface_1|count_2\(2),
	datad => \I_ad5441_interface_1|count_2\(1),
	combout => \I_ad5441_interface_1|Add0~1_combout\);

-- Location: LCCOMB_X17_Y37_N8
\I_ad5441_interface_1|count_2~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|count_2~8_combout\ = (((!\I_ad5441_interface_1|Add0~1_combout\) # (!\I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\SYS_RESET~input_o\)) # (!\I_power_on_reset|reset_t~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datab => \SYS_RESET~input_o\,
	datac => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datad => \I_ad5441_interface_1|Add0~1_combout\,
	combout => \I_ad5441_interface_1|count_2~8_combout\);

-- Location: FF_X17_Y37_N9
\I_ad5441_interface_1|count_2[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|count_2~8_combout\,
	ena => \I_ad5441_interface_1|count_2[1]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|count_2\(2));

-- Location: LCCOMB_X18_Y37_N16
\I_ad5441_interface_1|Selector5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector5~0_combout\ = (dac_data(6) & (((\I_ad5441_interface_1|dac_data_t\(7) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(6) & 
-- (((\I_ad5441_interface_1|dac_data_t\(7) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(6),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(7),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector5~0_combout\);

-- Location: FF_X18_Y37_N17
\I_ad5441_interface_1|dac_data_t[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector5~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(7));

-- Location: LCCOMB_X16_Y35_N8
\I_ads8330_interface|Selector29~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector29~0_combout\ = (\I_ads8330_interface|Selector25~0_combout\ & ((\I_ads8330_interface|adc_data_t\(10)) # ((\I_ads8330_interface|adc_data\(10) & \I_ads8330_interface|Selector39~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector25~0_combout\ & (((\I_ads8330_interface|adc_data\(10) & \I_ads8330_interface|Selector39~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector25~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(10),
	datac => \I_ads8330_interface|adc_data\(10),
	datad => \I_ads8330_interface|Selector39~0_combout\,
	combout => \I_ads8330_interface|Selector29~0_combout\);

-- Location: FF_X16_Y35_N9
\I_ads8330_interface|adc_data[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector29~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(10));

-- Location: LCCOMB_X16_Y37_N24
\dac_data~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~5_combout\ = (\I_power_on_reset|reset_t~q\ & (\SYS_RESET~input_o\ & \I_ads8330_interface|adc_data\(10)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_power_on_reset|reset_t~q\,
	datac => \SYS_RESET~input_o\,
	datad => \I_ads8330_interface|adc_data\(10),
	combout => \dac_data~5_combout\);

-- Location: FF_X16_Y37_N25
\dac_data[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~5_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(5));

-- Location: LCCOMB_X16_Y37_N16
\I_ad5441_interface_1|Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector6~0_combout\ = (\I_ad5441_interface_1|next_state.data_transfer~q\ & ((\I_ad5441_interface_1|dac_data_t\(6)) # ((!\I_ad5441_interface_1|next_state.idle~q\ & dac_data(5))))) # (!\I_ad5441_interface_1|next_state.data_transfer~q\ 
-- & (!\I_ad5441_interface_1|next_state.idle~q\ & ((dac_data(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(6),
	datad => dac_data(5),
	combout => \I_ad5441_interface_1|Selector6~0_combout\);

-- Location: FF_X16_Y37_N17
\I_ad5441_interface_1|dac_data_t[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector6~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(6));

-- Location: LCCOMB_X16_Y37_N4
\I_ad5441_interface_1|Selector8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector8~0_combout\ = (dac_data(3) & (((\I_ad5441_interface_1|dac_data_t\(4) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(3) & 
-- (((\I_ad5441_interface_1|dac_data_t\(4) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(3),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(4),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector8~0_combout\);

-- Location: FF_X16_Y37_N5
\I_ad5441_interface_1|dac_data_t[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector8~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(4));

-- Location: LCCOMB_X17_Y37_N28
\I_ad5441_interface_1|Mux0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~2_combout\ = (\I_ad5441_interface_1|count_2\(1) & (((\I_ad5441_interface_1|count_2\(0))))) # (!\I_ad5441_interface_1|count_2\(1) & ((\I_ad5441_interface_1|count_2\(0) & (\I_ad5441_interface_1|dac_data_t\(5))) # 
-- (!\I_ad5441_interface_1|count_2\(0) & ((\I_ad5441_interface_1|dac_data_t\(4))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_data_t\(5),
	datab => \I_ad5441_interface_1|count_2\(1),
	datac => \I_ad5441_interface_1|dac_data_t\(4),
	datad => \I_ad5441_interface_1|count_2\(0),
	combout => \I_ad5441_interface_1|Mux0~2_combout\);

-- Location: LCCOMB_X17_Y37_N30
\I_ad5441_interface_1|Mux0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~3_combout\ = (\I_ad5441_interface_1|count_2\(1) & ((\I_ad5441_interface_1|Mux0~2_combout\ & (\I_ad5441_interface_1|dac_data_t\(7))) # (!\I_ad5441_interface_1|Mux0~2_combout\ & ((\I_ad5441_interface_1|dac_data_t\(6)))))) # 
-- (!\I_ad5441_interface_1|count_2\(1) & (((\I_ad5441_interface_1|Mux0~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_2\(1),
	datab => \I_ad5441_interface_1|dac_data_t\(7),
	datac => \I_ad5441_interface_1|dac_data_t\(6),
	datad => \I_ad5441_interface_1|Mux0~2_combout\,
	combout => \I_ad5441_interface_1|Mux0~3_combout\);

-- Location: LCCOMB_X17_Y35_N8
\I_ads8330_interface|Selector17~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector17~0_combout\ = (\I_ads8330_interface|adc_data_t\(4) & ((\I_ads8330_interface|Selector8~0_combout\) # ((\I_ads8330_interface|adc_data_t\(5) & \I_ads8330_interface|Selector8~1_combout\)))) # 
-- (!\I_ads8330_interface|adc_data_t\(4) & (((\I_ads8330_interface|adc_data_t\(5) & \I_ads8330_interface|Selector8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|adc_data_t\(4),
	datab => \I_ads8330_interface|Selector8~0_combout\,
	datac => \I_ads8330_interface|adc_data_t\(5),
	datad => \I_ads8330_interface|Selector8~1_combout\,
	combout => \I_ads8330_interface|Selector17~0_combout\);

-- Location: FF_X17_Y35_N9
\I_ads8330_interface|adc_data_t[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector17~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data_t\(5));

-- Location: LCCOMB_X17_Y35_N30
\I_ads8330_interface|Selector34~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ads8330_interface|Selector34~0_combout\ = (\I_ads8330_interface|Selector39~0_combout\ & ((\I_ads8330_interface|adc_data\(5)) # ((\I_ads8330_interface|adc_data_t\(5) & \I_ads8330_interface|Selector25~0_combout\)))) # 
-- (!\I_ads8330_interface|Selector39~0_combout\ & (\I_ads8330_interface|adc_data_t\(5) & ((\I_ads8330_interface|Selector25~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ads8330_interface|Selector39~0_combout\,
	datab => \I_ads8330_interface|adc_data_t\(5),
	datac => \I_ads8330_interface|adc_data\(5),
	datad => \I_ads8330_interface|Selector25~0_combout\,
	combout => \I_ads8330_interface|Selector34~0_combout\);

-- Location: FF_X17_Y35_N31
\I_ads8330_interface|adc_data[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ads8330_interface|Selector34~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ads8330_interface|adc_data\(5));

-- Location: LCCOMB_X15_Y37_N26
\dac_data~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \dac_data~10_combout\ = (\I_power_on_reset|reset_t~q\ & (\I_ads8330_interface|adc_data\(5) & \SYS_RESET~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_power_on_reset|reset_t~q\,
	datac => \I_ads8330_interface|adc_data\(5),
	datad => \SYS_RESET~input_o\,
	combout => \dac_data~10_combout\);

-- Location: FF_X15_Y37_N27
\dac_data[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \dac_data~10_combout\,
	ena => \dac_data[10]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => dac_data(0));

-- Location: LCCOMB_X18_Y37_N12
\I_ad5441_interface_1|Selector11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector11~0_combout\ = (\I_ad5441_interface_1|next_state.data_transfer~q\ & ((\I_ad5441_interface_1|dac_data_t\(1)) # ((dac_data(0) & !\I_ad5441_interface_1|next_state.idle~q\)))) # 
-- (!\I_ad5441_interface_1|next_state.data_transfer~q\ & (dac_data(0) & ((!\I_ad5441_interface_1|next_state.idle~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|next_state.data_transfer~q\,
	datab => dac_data(0),
	datac => \I_ad5441_interface_1|dac_data_t\(1),
	datad => \I_ad5441_interface_1|next_state.idle~q\,
	combout => \I_ad5441_interface_1|Selector11~0_combout\);

-- Location: FF_X18_Y37_N13
\I_ad5441_interface_1|dac_data_t[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector11~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(1));

-- Location: LCCOMB_X17_Y37_N26
\I_ad5441_interface_1|Mux0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~4_combout\ = (\I_ad5441_interface_1|count_2\(0) & ((\I_ad5441_interface_1|count_2\(1) & (\I_ad5441_interface_1|dac_data_t\(3))) # (!\I_ad5441_interface_1|count_2\(1) & ((\I_ad5441_interface_1|dac_data_t\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_data_t\(3),
	datab => \I_ad5441_interface_1|count_2\(1),
	datac => \I_ad5441_interface_1|dac_data_t\(1),
	datad => \I_ad5441_interface_1|count_2\(0),
	combout => \I_ad5441_interface_1|Mux0~4_combout\);

-- Location: LCCOMB_X17_Y37_N12
\I_ad5441_interface_1|Mux0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~5_combout\ = (\I_ad5441_interface_1|Mux0~4_combout\) # ((\I_ad5441_interface_1|dac_data_t\(2) & (!\I_ad5441_interface_1|count_2\(0) & \I_ad5441_interface_1|count_2\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_data_t\(2),
	datab => \I_ad5441_interface_1|count_2\(0),
	datac => \I_ad5441_interface_1|Mux0~4_combout\,
	datad => \I_ad5441_interface_1|count_2\(1),
	combout => \I_ad5441_interface_1|Mux0~5_combout\);

-- Location: LCCOMB_X17_Y37_N22
\I_ad5441_interface_1|Mux0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~6_combout\ = (\I_ad5441_interface_1|count_2\(3) & (\I_ad5441_interface_1|count_2\(2))) # (!\I_ad5441_interface_1|count_2\(3) & ((\I_ad5441_interface_1|count_2\(2) & (\I_ad5441_interface_1|Mux0~3_combout\)) # 
-- (!\I_ad5441_interface_1|count_2\(2) & ((\I_ad5441_interface_1|Mux0~5_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_2\(3),
	datab => \I_ad5441_interface_1|count_2\(2),
	datac => \I_ad5441_interface_1|Mux0~3_combout\,
	datad => \I_ad5441_interface_1|Mux0~5_combout\,
	combout => \I_ad5441_interface_1|Mux0~6_combout\);

-- Location: LCCOMB_X18_Y37_N24
\I_ad5441_interface_1|Selector0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Selector0~0_combout\ = (dac_data(11) & (((\I_ad5441_interface_1|dac_data_t\(12) & \I_ad5441_interface_1|next_state.data_transfer~q\)) # (!\I_ad5441_interface_1|next_state.idle~q\))) # (!dac_data(11) & 
-- (((\I_ad5441_interface_1|dac_data_t\(12) & \I_ad5441_interface_1|next_state.data_transfer~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => dac_data(11),
	datab => \I_ad5441_interface_1|next_state.idle~q\,
	datac => \I_ad5441_interface_1|dac_data_t\(12),
	datad => \I_ad5441_interface_1|next_state.data_transfer~q\,
	combout => \I_ad5441_interface_1|Selector0~0_combout\);

-- Location: FF_X18_Y37_N25
\I_ad5441_interface_1|dac_data_t[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|Selector0~0_combout\,
	sclr => \reset~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_data_t\(12));

-- Location: LCCOMB_X17_Y37_N0
\I_ad5441_interface_1|Mux0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~7_combout\ = (!\I_ad5441_interface_1|count_2\(1) & (\I_ad5441_interface_1|dac_data_t\(12) & !\I_ad5441_interface_1|count_2\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \I_ad5441_interface_1|count_2\(1),
	datac => \I_ad5441_interface_1|dac_data_t\(12),
	datad => \I_ad5441_interface_1|count_2\(0),
	combout => \I_ad5441_interface_1|Mux0~7_combout\);

-- Location: LCCOMB_X17_Y37_N2
\I_ad5441_interface_1|Mux0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|Mux0~8_combout\ = (\I_ad5441_interface_1|count_2\(3) & ((\I_ad5441_interface_1|Mux0~6_combout\ & ((\I_ad5441_interface_1|Mux0~7_combout\))) # (!\I_ad5441_interface_1|Mux0~6_combout\ & (\I_ad5441_interface_1|Mux0~1_combout\)))) # 
-- (!\I_ad5441_interface_1|count_2\(3) & (((\I_ad5441_interface_1|Mux0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|count_2\(3),
	datab => \I_ad5441_interface_1|Mux0~1_combout\,
	datac => \I_ad5441_interface_1|Mux0~6_combout\,
	datad => \I_ad5441_interface_1|Mux0~7_combout\,
	combout => \I_ad5441_interface_1|Mux0~8_combout\);

-- Location: LCCOMB_X17_Y37_N24
\I_ad5441_interface_1|dac_sri_t~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_1|dac_sri_t~0_combout\ = (\I_ad5441_interface_1|dac_clk_t~q\ & ((\I_ad5441_interface_1|Mux0~8_combout\))) # (!\I_ad5441_interface_1|dac_clk_t~q\ & (\I_ad5441_interface_1|dac_sri_t~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \I_ad5441_interface_1|dac_clk_t~q\,
	datac => \I_ad5441_interface_1|dac_sri_t~q\,
	datad => \I_ad5441_interface_1|Mux0~8_combout\,
	combout => \I_ad5441_interface_1|dac_sri_t~0_combout\);

-- Location: FF_X17_Y37_N25
\I_ad5441_interface_1|dac_sri_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|dac_sri_t~0_combout\,
	asdata => \~GND~combout\,
	sclr => \reset~combout\,
	sload => \I_ad5441_interface_1|ALT_INV_next_state.data_transfer~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_1|dac_sri_t~q\);

-- Location: LCCOMB_X35_Y22_N26
\I_ad5441_interface_2|dac_ld_n_t~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_2|dac_ld_n_t~feeder_combout\ = \I_ad5441_interface_1|dac_ld_n_t~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	combout => \I_ad5441_interface_2|dac_ld_n_t~feeder_combout\);

-- Location: FF_X35_Y22_N27
\I_ad5441_interface_2|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_2|dac_ld_n_t~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_2|dac_ld_n_t~q\);

-- Location: LCCOMB_X35_Y22_N28
\I_ad5441_interface_3|dac_ld_n_t~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_3|dac_ld_n_t~feeder_combout\ = \I_ad5441_interface_1|dac_ld_n_t~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	combout => \I_ad5441_interface_3|dac_ld_n_t~feeder_combout\);

-- Location: FF_X35_Y22_N29
\I_ad5441_interface_3|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_3|dac_ld_n_t~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_3|dac_ld_n_t~q\);

-- Location: LCCOMB_X35_Y22_N6
\I_ad5441_interface_4|dac_ld_n_t~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_4|dac_ld_n_t~feeder_combout\ = \I_ad5441_interface_1|dac_ld_n_t~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	combout => \I_ad5441_interface_4|dac_ld_n_t~feeder_combout\);

-- Location: FF_X35_Y22_N7
\I_ad5441_interface_4|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_4|dac_ld_n_t~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_4|dac_ld_n_t~q\);

-- Location: LCCOMB_X35_Y22_N24
\I_ad5441_interface_5|dac_ld_n_t~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \I_ad5441_interface_5|dac_ld_n_t~feeder_combout\ = \I_ad5441_interface_1|dac_ld_n_t~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	combout => \I_ad5441_interface_5|dac_ld_n_t~feeder_combout\);

-- Location: FF_X35_Y22_N25
\I_ad5441_interface_5|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_5|dac_ld_n_t~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_5|dac_ld_n_t~q\);

-- Location: FF_X16_Y36_N31
\I_ad5441_interface_6|dac_ld_n_t\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKY2~inputclkctrl_outclk\,
	d => \I_ad5441_interface_1|dac_ld_n_t~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \I_ad5441_interface_6|dac_ld_n_t~q\);

ww_AD_CONVST <= \AD_CONVST~output_o\;

ww_AD_SCLK <= \AD_SCLK~output_o\;

ww_AD_CS <= \AD_CS~output_o\;

ww_AD_SDI <= \AD_SDI~output_o\;

ww_DA_CLK <= \DA_CLK~output_o\;

ww_DA1_LD <= \DA1_LD~output_o\;

ww_DA1_SRI <= \DA1_SRI~output_o\;

ww_DA2_LD <= \DA2_LD~output_o\;

ww_DA2_SRI <= \DA2_SRI~output_o\;

ww_DA3_LD <= \DA3_LD~output_o\;

ww_DA3_SRI <= \DA3_SRI~output_o\;

ww_DA4_LD <= \DA4_LD~output_o\;

ww_DA4_SRI <= \DA4_SRI~output_o\;

ww_DA5_LD <= \DA5_LD~output_o\;

ww_DA5_SRI <= \DA5_SRI~output_o\;

ww_DA6_LD <= \DA6_LD~output_o\;

ww_DA6_SRI <= \DA6_SRI~output_o\;

ww_LED(0) <= \LED[0]~output_o\;

ww_LED(1) <= \LED[1]~output_o\;

ww_LED(2) <= \LED[2]~output_o\;

ww_LED(3) <= \LED[3]~output_o\;
END structure;


